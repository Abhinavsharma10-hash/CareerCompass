import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import { AuthProvider } from './contexts/AuthContext';
import { DataProvider } from './contexts/DataContext';
import { ChatProvider } from './contexts/ChatContext';
import LoginPage from './pages/LoginPage';
import HomePage from './pages/HomePage';
import AddCompanyPage from './pages/AddCompanyPage';
import CompanyProfilePage from './pages/CompanyProfilePage';
import LearningRoadmapPage from './pages/LearningRoadmapPage';
import NotificationsPage from './pages/NotificationsPage';
import ResumeTipsPage from './pages/ResumeTipsPage';
import RequirementsPage from './pages/RequirementsPage';
import AutoApplicationsPage from './pages/AutoApplicationsPage';
import StartupIdeasPage from './pages/StartupIdeasPage';
import Layout from './components/Layout';
import ProtectedRoute from './components/ProtectedRoute';
import ChatBot from './components/ChatBot';

function App() {
  return (
    <Router>
      <AuthProvider>
        <DataProvider>
          <ChatProvider>
            <Routes>
              <Route path="/login" element={<LoginPage />} />
              <Route path="/" element={<ProtectedRoute><Layout /></ProtectedRoute>}>
                <Route index element={<HomePage />} />
                <Route path="add-company" element={<AddCompanyPage />} />
                <Route path="company/:id" element={<CompanyProfilePage />} />
                <Route path="roadmap" element={<LearningRoadmapPage />} />
                <Route path="notifications" element={<NotificationsPage />} />
                <Route path="resume-tips" element={<ResumeTipsPage />} />
                <Route path="requirements" element={<RequirementsPage />} />
                <Route path="auto-applications" element={<AutoApplicationsPage />} />
                <Route path="startup-ideas" element={<StartupIdeasPage />} />
              </Route>
            </Routes>
            <ChatBot />
          </ChatProvider>
        </DataProvider>
      </AuthProvider>
    </Router>
  );
}

export default App;