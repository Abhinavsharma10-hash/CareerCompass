import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { Target, Plus, Edit2, Trash2, Save, X } from 'lucide-react';

const RequirementsPage: React.FC = () => {
  const { userRequirements, addRequirement, updateRequirement, deleteRequirement } = useData();
  const [isAdding, setIsAdding] = useState(false);
  const [editingId, setEditingId] = useState<string | null>(null);
  const [formData, setFormData] = useState({
    type: 'role' as const,
    value: '',
    priority: 'medium' as const
  });

  const requirementTypes = [
    { value: 'role', label: 'Job Role', placeholder: 'e.g., Software Engineer, Data Scientist' },
    { value: 'location', label: 'Location', placeholder: 'e.g., San Francisco, Remote' },
    { value: 'salary', label: 'Salary Range', placeholder: 'e.g., $80k - $120k' },
    { value: 'experience', label: 'Experience Level', placeholder: 'e.g., Entry Level, 2-5 years' },
    { value: 'skills', label: 'Required Skills', placeholder: 'e.g., React, Python, Machine Learning' },
    { value: 'industry', label: 'Industry', placeholder: 'e.g., Technology, Healthcare, Finance' }
  ];

  const priorityColors = {
    high: 'bg-red-100 text-red-800 border-red-200',
    medium: 'bg-yellow-100 text-yellow-800 border-yellow-200',
    low: 'bg-green-100 text-green-800 border-green-200'
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.value.trim()) return;

    if (editingId) {
      updateRequirement(editingId, formData);
      setEditingId(null);
    } else {
      addRequirement(formData);
      setIsAdding(false);
    }

    setFormData({ type: 'role', value: '', priority: 'medium' });
  };

  const handleEdit = (requirement: any) => {
    setFormData({
      type: requirement.type,
      value: requirement.value,
      priority: requirement.priority
    });
    setEditingId(requirement.id);
    setIsAdding(false);
  };

  const handleCancel = () => {
    setIsAdding(false);
    setEditingId(null);
    setFormData({ type: 'role', value: '', priority: 'medium' });
  };

  const groupedRequirements = userRequirements.reduce((acc, req) => {
    if (!acc[req.type]) acc[req.type] = [];
    acc[req.type].push(req);
    return acc;
  }, {} as Record<string, typeof userRequirements>);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">Career Requirements</h1>
            <p className="text-blue-100">
              Define your career preferences to get personalized recommendations
            </p>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{userRequirements.length}</div>
              <div className="text-sm text-blue-100">Requirements</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-md border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center justify-between">
            <h2 className="text-xl font-semibold text-gray-900">Your Requirements</h2>
            <button
              onClick={() => setIsAdding(true)}
              className="bg-gradient-to-r from-green-500 to-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:from-green-600 hover:to-blue-700 transition-all duration-200 flex items-center space-x-2"
            >
              <Plus className="h-4 w-4" />
              <span>Add Requirement</span>
            </button>
          </div>
        </div>

        <div className="p-6">
          {(isAdding || editingId) && (
            <div className="bg-gray-50 border border-gray-200 rounded-lg p-4 mb-6">
              <h3 className="font-medium text-gray-900 mb-4">
                {editingId ? 'Edit Requirement' : 'Add New Requirement'}
              </h3>
              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Type
                    </label>
                    <select
                      value={formData.type}
                      onChange={(e) => setFormData({...formData, type: e.target.value as any})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      {requirementTypes.map(type => (
                        <option key={type.value} value={type.value}>
                          {type.label}
                        </option>
                      ))}
                    </select>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Value
                    </label>
                    <input
                      type="text"
                      value={formData.value}
                      onChange={(e) => setFormData({...formData, value: e.target.value})}
                      placeholder={requirementTypes.find(t => t.value === formData.type)?.placeholder}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                      required
                    />
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-2">
                      Priority
                    </label>
                    <select
                      value={formData.priority}
                      onChange={(e) => setFormData({...formData, priority: e.target.value as any})}
                      className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="high">High</option>
                      <option value="medium">Medium</option>
                      <option value="low">Low</option>
                    </select>
                  </div>
                </div>

                <div className="flex space-x-3">
                  <button
                    type="submit"
                    className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-lg font-medium hover:from-blue-600 hover:to-purple-700 transition-all duration-200 flex items-center space-x-2"
                  >
                    <Save className="h-4 w-4" />
                    <span>{editingId ? 'Update' : 'Add'}</span>
                  </button>
                  <button
                    type="button"
                    onClick={handleCancel}
                    className="bg-gray-100 text-gray-700 px-4 py-2 rounded-lg font-medium hover:bg-gray-200 transition-colors duration-200 flex items-center space-x-2"
                  >
                    <X className="h-4 w-4" />
                    <span>Cancel</span>
                  </button>
                </div>
              </form>
            </div>
          )}

          {userRequirements.length === 0 ? (
            <div className="text-center py-12">
              <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No requirements yet</h3>
              <p className="text-gray-600 mb-6">
                Add your career requirements to get personalized job recommendations
              </p>
              <button
                onClick={() => setIsAdding(true)}
                className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:from-blue-600 hover:to-purple-700 transition-all duration-200"
              >
                <Plus className="h-5 w-5" />
                <span>Add First Requirement</span>
              </button>
            </div>
          ) : (
            <div className="space-y-6">
              {requirementTypes.map(type => {
                const requirements = groupedRequirements[type.value] || [];
                if (requirements.length === 0) return null;

                return (
                  <div key={type.value}>
                    <h3 className="text-lg font-medium text-gray-900 mb-3 capitalize">
                      {type.label}
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                      {requirements.map(requirement => (
                        <div
                          key={requirement.id}
                          className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow duration-200"
                        >
                          <div className="flex items-start justify-between mb-2">
                            <div className="flex-1">
                              <p className="font-medium text-gray-900">{requirement.value}</p>
                              <span className={`inline-block px-2 py-1 rounded-full text-xs font-medium border ${priorityColors[requirement.priority]} mt-2`}>
                                {requirement.priority} priority
                              </span>
                            </div>
                            <div className="flex space-x-1 ml-2">
                              <button
                                onClick={() => handleEdit(requirement)}
                                className="text-blue-600 hover:text-blue-700 p-1"
                              >
                                <Edit2 className="h-4 w-4" />
                              </button>
                              <button
                                onClick={() => deleteRequirement(requirement.id)}
                                className="text-red-600 hover:text-red-700 p-1"
                              >
                                <Trash2 className="h-4 w-4" />
                              </button>
                            </div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-xl p-6 text-white">
        <h2 className="text-xl font-bold mb-2">💡 Pro Tip</h2>
        <p className="text-yellow-100">
          Be specific with your requirements! The more detailed you are, the better our AI can match you with relevant opportunities and provide personalized career guidance.
        </p>
      </div>
    </div>
  );
};

export default RequirementsPage;