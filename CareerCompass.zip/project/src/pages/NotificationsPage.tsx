import React from 'react';
import { useData } from '../contexts/DataContext';
import { Bell, Calendar, ExternalLink, Briefcase, GraduationCap, Users } from 'lucide-react';

const NotificationsPage: React.FC = () => {
  const { notifications, markNotificationAsRead } = useData();

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case 'internship':
        return <Briefcase className="h-5 w-5 text-blue-600" />;
      case 'drive':
        return <GraduationCap className="h-5 w-5 text-green-600" />;
      case 'event':
        return <Users className="h-5 w-5 text-purple-600" />;
      default:
        return <Bell className="h-5 w-5 text-gray-600" />;
    }
  };

  const getNotificationColor = (type: string) => {
    switch (type) {
      case 'internship':
        return 'bg-blue-50 border-blue-200';
      case 'drive':
        return 'bg-green-50 border-green-200';
      case 'event':
        return 'bg-purple-50 border-purple-200';
      default:
        return 'bg-gray-50 border-gray-200';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const unreadNotifications = notifications.filter(n => !n.read);
  const readNotifications = notifications.filter(n => n.read);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-6">
          <div>
            <h1 className="text-2xl font-bold text-gray-900">Notifications</h1>
            <p className="text-gray-600">Stay updated with the latest opportunities</p>
          </div>
          <div className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-lg">
            <div className="flex items-center space-x-2">
              <Bell className="h-5 w-5" />
              <span className="font-medium">{unreadNotifications.length} new</span>
            </div>
          </div>
        </div>

        {notifications.length === 0 ? (
          <div className="text-center py-12">
            <Bell className="h-12 w-12 text-gray-400 mx-auto mb-4" />
            <h2 className="text-xl font-semibold text-gray-900 mb-2">No notifications yet</h2>
            <p className="text-gray-600">
              We'll notify you about new opportunities and events here
            </p>
          </div>
        ) : (
          <div className="space-y-6">
            {unreadNotifications.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">New Notifications</h2>
                <div className="space-y-4">
                  {unreadNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className={`border rounded-lg p-4 ${getNotificationColor(notification.type)} hover:shadow-md transition-shadow duration-200`}
                    >
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0 mt-1">
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-medium text-gray-900 mb-1">
                                {notification.title}
                              </h3>
                              <div className="flex items-center space-x-2 text-sm text-gray-600 mb-3">
                                <Calendar className="h-4 w-4" />
                                <span>{formatDate(notification.date)}</span>
                                <span className="px-2 py-1 bg-white rounded-full text-xs font-medium capitalize">
                                  {notification.type}
                                </span>
                              </div>
                            </div>
                            <div className="flex space-x-2">
                              <a
                                href={notification.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:text-blue-700"
                              >
                                <ExternalLink className="h-4 w-4" />
                              </a>
                            </div>
                          </div>
                          <button
                            onClick={() => markNotificationAsRead(notification.id)}
                            className="text-sm text-blue-600 hover:text-blue-700 font-medium"
                          >
                            Mark as read
                          </button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {readNotifications.length > 0 && (
              <div>
                <h2 className="text-lg font-semibold text-gray-900 mb-4">Previous Notifications</h2>
                <div className="space-y-4">
                  {readNotifications.map((notification) => (
                    <div
                      key={notification.id}
                      className="border border-gray-200 rounded-lg p-4 bg-gray-50 opacity-75"
                    >
                      <div className="flex items-start space-x-4">
                        <div className="flex-shrink-0 mt-1">
                          {getNotificationIcon(notification.type)}
                        </div>
                        <div className="flex-1 min-w-0">
                          <div className="flex items-start justify-between">
                            <div>
                              <h3 className="font-medium text-gray-700 mb-1">
                                {notification.title}
                              </h3>
                              <div className="flex items-center space-x-2 text-sm text-gray-500">
                                <Calendar className="h-4 w-4" />
                                <span>{formatDate(notification.date)}</span>
                                <span className="px-2 py-1 bg-white rounded-full text-xs font-medium capitalize">
                                  {notification.type}
                                </span>
                              </div>
                            </div>
                            <a
                              href={notification.url}
                              target="_blank"
                              rel="noopener noreferrer"
                              className="text-gray-500 hover:text-gray-700"
                            >
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          </div>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        )}
      </div>
    </div>
  );
};

export default NotificationsPage;