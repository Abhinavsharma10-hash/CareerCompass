import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { Zap, Filter, Calendar, TrendingUp, CheckCircle, Clock, X, ExternalLink } from 'lucide-react';

const AutoApplicationsPage: React.FC = () => {
  const { autoApplications, applyToOpportunity, userRequirements } = useData();
  const [filterType, setFilterType] = useState<'all' | 'internship' | 'workshop' | 'program'>('all');
  const [filterStatus, setFilterStatus] = useState<'all' | 'pending' | 'applied' | 'rejected' | 'accepted'>('all');

  const filteredApplications = autoApplications.filter(app => {
    const typeMatch = filterType === 'all' || app.type === filterType;
    const statusMatch = filterStatus === 'all' || app.status === filterStatus;
    return typeMatch && statusMatch;
  });

  const getStatusIcon = (status: string) => {
    switch (status) {
      case 'applied':
        return <CheckCircle className="h-4 w-4 text-green-600" />;
      case 'pending':
        return <Clock className="h-4 w-4 text-yellow-600" />;
      case 'rejected':
        return <X className="h-4 w-4 text-red-600" />;
      case 'accepted':
        return <CheckCircle className="h-4 w-4 text-blue-600" />;
      default:
        return <Clock className="h-4 w-4 text-gray-600" />;
    }
  };

  const getStatusColor = (status: string) => {
    switch (status) {
      case 'applied':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'pending':
        return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'rejected':
        return 'bg-red-100 text-red-800 border-red-200';
      case 'accepted':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const getTypeColor = (type: string) => {
    switch (type) {
      case 'internship':
        return 'bg-blue-100 text-blue-800';
      case 'workshop':
        return 'bg-purple-100 text-purple-800';
      case 'program':
        return 'bg-green-100 text-green-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  const formatDate = (dateString: string) => {
    return new Date(dateString).toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'short',
      day: 'numeric'
    });
  };

  const getDaysUntilDeadline = (deadline: string) => {
    const today = new Date();
    const deadlineDate = new Date(deadline);
    const diffTime = deadlineDate.getTime() - today.getTime();
    const diffDays = Math.ceil(diffTime / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  const stats = {
    total: autoApplications.length,
    pending: autoApplications.filter(app => app.status === 'pending').length,
    applied: autoApplications.filter(app => app.status === 'applied').length,
    avgMatch: Math.round(autoApplications.reduce((sum, app) => sum + app.matchScore, 0) / autoApplications.length) || 0
  };

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">Auto Applications</h1>
            <p className="text-blue-100">
              AI-powered opportunity matching based on your requirements
            </p>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{stats.avgMatch}%</div>
              <div className="text-sm text-blue-100">Avg Match</div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-md border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-100 p-2 rounded-lg">
              <Zap className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{stats.total}</div>
              <div className="text-sm text-gray-600">Total Opportunities</div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-md border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="bg-yellow-100 p-2 rounded-lg">
              <Clock className="h-6 w-6 text-yellow-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{stats.pending}</div>
              <div className="text-sm text-gray-600">Pending</div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-md border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="bg-green-100 p-2 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{stats.applied}</div>
              <div className="text-sm text-gray-600">Applied</div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-md border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="bg-purple-100 p-2 rounded-lg">
              <TrendingUp className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{userRequirements.length}</div>
              <div className="text-sm text-gray-600">Requirements</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-md border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
            <h2 className="text-xl font-semibold text-gray-900">Available Opportunities</h2>
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Filter className="h-4 w-4 text-gray-600" />
                <select
                  value={filterType}
                  onChange={(e) => setFilterType(e.target.value as any)}
                  className="border border-gray-300 rounded-lg px-3 py-1 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="all">All Types</option>
                  <option value="internship">Internships</option>
                  <option value="workshop">Workshops</option>
                  <option value="program">Programs</option>
                </select>
              </div>
              <select
                value={filterStatus}
                onChange={(e) => setFilterStatus(e.target.value as any)}
                className="border border-gray-300 rounded-lg px-3 py-1 text-sm focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Status</option>
                <option value="pending">Pending</option>
                <option value="applied">Applied</option>
                <option value="rejected">Rejected</option>
                <option value="accepted">Accepted</option>
              </select>
            </div>
          </div>
        </div>

        <div className="p-6">
          {filteredApplications.length === 0 ? (
            <div className="text-center py-12">
              <Zap className="h-12 w-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-medium text-gray-900 mb-2">No opportunities found</h3>
              <p className="text-gray-600">
                Try adjusting your filters or add more requirements to get better matches
              </p>
            </div>
          ) : (
            <div className="space-y-4">
              {filteredApplications.map((application) => {
                const daysLeft = getDaysUntilDeadline(application.deadline);
                const isUrgent = daysLeft <= 7 && daysLeft > 0;
                const isExpired = daysLeft < 0;

                return (
                  <div
                    key={application.id}
                    className={`border rounded-lg p-6 hover:shadow-md transition-shadow duration-200 ${
                      isUrgent ? 'border-orange-300 bg-orange-50' : 
                      isExpired ? 'border-red-300 bg-red-50' : 'border-gray-200'
                    }`}
                  >
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-2">
                          <h3 className="text-lg font-semibold text-gray-900">
                            {application.title}
                          </h3>
                          <span className={`px-2 py-1 rounded-full text-xs font-medium ${getTypeColor(application.type)}`}>
                            {application.type}
                          </span>
                          <div className="flex items-center space-x-1">
                            {getStatusIcon(application.status)}
                            <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getStatusColor(application.status)}`}>
                              {application.status}
                            </span>
                          </div>
                        </div>

                        <p className="text-gray-600 mb-3">{application.company}</p>

                        <div className="flex items-center space-x-6 mb-4">
                          <div className="flex items-center space-x-2">
                            <Calendar className="h-4 w-4 text-gray-500" />
                            <span className="text-sm text-gray-600">
                              Deadline: {formatDate(application.deadline)}
                              {daysLeft > 0 && (
                                <span className={`ml-1 ${isUrgent ? 'text-orange-600 font-medium' : 'text-gray-500'}`}>
                                  ({daysLeft} days left)
                                </span>
                              )}
                              {isExpired && (
                                <span className="ml-1 text-red-600 font-medium">(Expired)</span>
                              )}
                            </span>
                          </div>
                          <div className="flex items-center space-x-2">
                            <TrendingUp className="h-4 w-4 text-gray-500" />
                            <span className="text-sm text-gray-600">
                              {application.matchScore}% match
                            </span>
                            <div className="w-16 bg-gray-200 rounded-full h-2">
                              <div
                                className={`h-2 rounded-full ${
                                  application.matchScore >= 90 ? 'bg-green-500' :
                                  application.matchScore >= 70 ? 'bg-yellow-500' : 'bg-red-500'
                                }`}
                                style={{ width: `${application.matchScore}%` }}
                              ></div>
                            </div>
                          </div>
                        </div>

                        <div className="mb-4">
                          <p className="text-sm font-medium text-gray-700 mb-2">Requirements:</p>
                          <div className="flex flex-wrap gap-2">
                            {application.requirements.map((req, index) => (
                              <span
                                key={index}
                                className="bg-gray-100 text-gray-700 px-2 py-1 rounded-md text-xs"
                              >
                                {req}
                              </span>
                            ))}
                          </div>
                        </div>
                      </div>

                      <div className="flex flex-col space-y-2 ml-4">
                        {application.status === 'pending' && !isExpired && (
                          <button
                            onClick={() => applyToOpportunity(application.id)}
                            className="bg-gradient-to-r from-green-500 to-blue-600 text-white px-4 py-2 rounded-lg font-medium hover:from-green-600 hover:to-blue-700 transition-all duration-200 text-sm"
                          >
                            Auto Apply
                          </button>
                        )}
                        <button className="text-blue-600 hover:text-blue-700 p-2">
                          <ExternalLink className="h-4 w-4" />
                        </button>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>
          )}
        </div>
      </div>

      <div className="bg-gradient-to-r from-green-400 to-blue-500 rounded-xl p-6 text-white">
        <h2 className="text-xl font-bold mb-2">🤖 AI-Powered Matching</h2>
        <p className="text-green-100">
          Our AI analyzes your requirements and automatically finds the best opportunities for you. 
          The more detailed your requirements, the better the matches!
        </p>
      </div>
    </div>
  );
};

export default AutoApplicationsPage;