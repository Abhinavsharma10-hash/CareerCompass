import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { 
  Lightbulb, 
  Plus, 
  TrendingUp, 
  Users, 
  DollarSign, 
  Target, 
  Rocket,
  Building,
  Star,
  Calendar,
  ExternalLink,
  Filter,
  Search,
  Upload,
  FileText,
  Download,
  Mail,
  Eye,
  Edit,
  Trash2,
  Send,
  X,
  CheckCircle,
  AlertCircle,
  Info
} from 'lucide-react';

interface StartupIdea {
  id: string;
  title: string;
  description: string;
  category: string;
  stage: 'idea' | 'prototype' | 'mvp' | 'launched';
  targetCompanies: string[];
  fundingGoal: string;
  teamSize: number;
  technologies: string[];
  marketSize: string;
  competition: 'low' | 'medium' | 'high';
  viability: number; // 1-10 scale
  createdAt: string;
  pitchDeck?: string;
  demoUrl?: string;
}

interface PitchDeckSlide {
  id: string;
  title: string;
  content: string;
  type: 'problem' | 'solution' | 'market' | 'product' | 'business' | 'team' | 'financial' | 'conclusion';
  file?: File;
}

interface Investor {
  id: string;
  name: string;
  company: string;
  focusAreas: string[];
  investmentRange: string;
  stage: string[];
  location: string;
  portfolio: string[];
  contactEmail: string;
  linkedIn?: string;
  twitter?: string;
}

const StartupIdeasPage: React.FC = () => {
  const { companies } = useData();
  const [activeTab, setActiveTab] = useState<'ideas' | 'pitch' | 'investors'>('ideas');
  const [filterCategory, setFilterCategory] = useState<string>('all');
  const [searchTerm, setSearchTerm] = useState('');
  const [showAddForm, setShowAddForm] = useState(false);
  const [showPitchBuilder, setShowPitchBuilder] = useState(false);
  const [showEmailModal, setShowEmailModal] = useState(false);
  const [selectedInvestor, setSelectedInvestor] = useState<Investor | null>(null);
  const [emailSubject, setEmailSubject] = useState('');
  const [emailBody, setEmailBody] = useState('');

  // Pitch deck slides state
  const [pitchSlides, setPitchSlides] = useState<PitchDeckSlide[]>([
    { id: '1', title: 'Problem Statement', content: '', type: 'problem' },
    { id: '2', title: 'Abstract', content: '', type: 'solution' },
    { id: '3', title: 'Solution', content: '', type: 'solution' },
    { id: '4', title: 'Technologies to be Used', content: '', type: 'product' },
    { id: '5', title: 'Advantages', content: '', type: 'business' },
    { id: '6', title: 'Future Scope', content: '', type: 'market' },
    { id: '7', title: 'Conclusion', content: '', type: 'conclusion' }
  ]);

  // Sample startup ideas
  const [startupIdeas] = useState<StartupIdea[]>([
    {
      id: '1',
      title: 'AI-Powered Code Review Assistant',
      description: 'An intelligent code review tool that uses machine learning to identify bugs, security vulnerabilities, and suggest optimizations.',
      category: 'Developer Tools',
      stage: 'prototype',
      targetCompanies: ['Google', 'Microsoft', 'Meta'],
      fundingGoal: '$500K - $1M',
      teamSize: 3,
      technologies: ['Python', 'TensorFlow', 'React', 'Node.js'],
      marketSize: '$2.5B',
      competition: 'medium',
      viability: 8,
      createdAt: '2024-01-15',
      demoUrl: 'https://demo.example.com'
    },
    {
      id: '2',
      title: 'Sustainable Supply Chain Tracker',
      description: 'Blockchain-based platform to track and verify sustainable practices across global supply chains.',
      category: 'Sustainability',
      stage: 'idea',
      targetCompanies: ['Amazon', 'Apple', 'Tesla'],
      fundingGoal: '$1M - $2M',
      teamSize: 4,
      technologies: ['Blockchain', 'React', 'Python', 'IoT'],
      marketSize: '$4.2B',
      competition: 'low',
      viability: 9,
      createdAt: '2024-01-10'
    },
    {
      id: '3',
      title: 'Virtual Reality Training Platform',
      description: 'Immersive VR platform for corporate training, focusing on soft skills and technical training.',
      category: 'EdTech',
      stage: 'mvp',
      targetCompanies: ['Meta', 'Microsoft', 'Google'],
      fundingGoal: '$2M - $5M',
      teamSize: 6,
      technologies: ['Unity', 'C#', 'WebXR', 'React'],
      marketSize: '$6.8B',
      competition: 'high',
      viability: 7,
      createdAt: '2024-01-05',
      pitchDeck: 'https://pitch.example.com'
    }
  ]);

  // Sample investors
  const [investors] = useState<Investor[]>([
    {
      id: '1',
      name: 'Sarah Chen',
      company: 'TechVentures Capital',
      focusAreas: ['AI/ML', 'Developer Tools', 'SaaS'],
      investmentRange: '$100K - $2M',
      stage: ['Seed', 'Series A'],
      location: 'San Francisco, CA',
      portfolio: ['GitHub', 'Figma', 'Notion'],
      contactEmail: 'sarah@techventures.com',
      linkedIn: 'https://linkedin.com/in/sarahchen',
      twitter: 'https://twitter.com/sarahchen'
    },
    {
      id: '2',
      name: 'Michael Rodriguez',
      company: 'Green Future Fund',
      focusAreas: ['Sustainability', 'CleanTech', 'ESG'],
      investmentRange: '$500K - $10M',
      stage: ['Series A', 'Series B'],
      location: 'Austin, TX',
      portfolio: ['Tesla', 'Beyond Meat', 'Patagonia'],
      contactEmail: 'michael@greenfuture.com',
      linkedIn: 'https://linkedin.com/in/michaelrodriguez'
    },
    {
      id: '3',
      name: 'Emily Watson',
      company: 'Innovation Labs',
      focusAreas: ['EdTech', 'VR/AR', 'Future of Work'],
      investmentRange: '$250K - $5M',
      stage: ['Pre-Seed', 'Seed', 'Series A'],
      location: 'New York, NY',
      portfolio: ['Coursera', 'Oculus', 'Zoom'],
      contactEmail: 'emily@innovationlabs.com',
      linkedIn: 'https://linkedin.com/in/emilywatson',
      twitter: 'https://twitter.com/emilywatson'
    }
  ]);

  const categories = ['all', 'Developer Tools', 'Sustainability', 'EdTech', 'FinTech', 'HealthTech', 'AI/ML'];

  const filteredIdeas = startupIdeas.filter(idea => {
    const categoryMatch = filterCategory === 'all' || idea.category === filterCategory;
    const searchMatch = idea.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                       idea.description.toLowerCase().includes(searchTerm.toLowerCase());
    return categoryMatch && searchMatch;
  });

  const getStageColor = (stage: string) => {
    switch (stage) {
      case 'idea': return 'bg-gray-100 text-gray-800';
      case 'prototype': return 'bg-blue-100 text-blue-800';
      case 'mvp': return 'bg-yellow-100 text-yellow-800';
      case 'launched': return 'bg-green-100 text-green-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const getCompetitionColor = (competition: string) => {
    switch (competition) {
      case 'low': return 'bg-green-100 text-green-800';
      case 'medium': return 'bg-yellow-100 text-yellow-800';
      case 'high': return 'bg-red-100 text-red-800';
      default: return 'bg-gray-100 text-gray-800';
    }
  };

  const handleFileUpload = (slideId: string, file: File) => {
    setPitchSlides(slides => 
      slides.map(slide => 
        slide.id === slideId ? { ...slide, file } : slide
      )
    );
  };

  const handleSlideContentChange = (slideId: string, content: string) => {
    setPitchSlides(slides => 
      slides.map(slide => 
        slide.id === slideId ? { ...slide, content } : slide
      )
    );
  };

  const handleEmailInvestor = (investor: Investor) => {
    setSelectedInvestor(investor);
    setEmailSubject(`Investment Opportunity - [Your Startup Name]`);
    setEmailBody(`Dear ${investor.name},

I hope this email finds you well. I'm reaching out to introduce you to an exciting investment opportunity that aligns with your focus areas in ${investor.focusAreas.join(', ')}.

[Brief description of your startup and why it's a good fit for their portfolio]

I would love to schedule a brief call to discuss this opportunity further and share our pitch deck with you.

Best regards,
[Your Name]
[Your Contact Information]`);
    setShowEmailModal(true);
  };

  const sendEmail = () => {
    if (selectedInvestor) {
      const mailtoLink = `mailto:${selectedInvestor.contactEmail}?subject=${encodeURIComponent(emailSubject)}&body=${encodeURIComponent(emailBody)}`;
      window.location.href = mailtoLink;
      setShowEmailModal(false);
    }
  };

  const investorTips = [
    {
      title: "Research Before Reaching Out",
      description: "Study the investor's portfolio, investment thesis, and recent activities. Personalize your approach.",
      icon: Search
    },
    {
      title: "Perfect Your Pitch",
      description: "Have a compelling 30-second elevator pitch and a detailed 10-minute presentation ready.",
      icon: Target
    },
    {
      title: "Show Traction",
      description: "Demonstrate user growth, revenue, partnerships, or other metrics that prove market validation.",
      icon: TrendingUp
    },
    {
      title: "Be Transparent",
      description: "Be honest about challenges, risks, and what you don't know. Investors appreciate transparency.",
      icon: CheckCircle
    },
    {
      title: "Follow Up Professionally",
      description: "Send thank you notes, provide requested information promptly, and maintain regular updates.",
      icon: Mail
    },
    {
      title: "Network Strategically",
      description: "Attend industry events, join startup communities, and get warm introductions when possible.",
      icon: Users
    }
  ];

  return (
    <div className="max-w-6xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-purple-500 to-pink-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold mb-2">Startup Ideas Hub</h1>
            <p className="text-purple-100">
              Build, pitch, and find investors for your innovative startup ideas
            </p>
          </div>
          <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4">
            <div className="text-center">
              <div className="text-2xl font-bold">{startupIdeas.length}</div>
              <div className="text-sm text-purple-100">Ideas</div>
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-md border border-gray-100">
        <div className="border-b border-gray-200">
          <nav className="flex space-x-8 px-6">
            {[
              { id: 'ideas', label: 'My Ideas', icon: Lightbulb },
              { id: 'pitch', label: 'Pitch Deck', icon: Target },
              { id: 'investors', label: 'Find Investors', icon: DollarSign }
            ].map((tab) => (
              <button
                key={tab.id}
                onClick={() => setActiveTab(tab.id as any)}
                className={`flex items-center space-x-2 py-4 px-2 border-b-2 font-medium text-sm transition-colors duration-200 ${
                  activeTab === tab.id
                    ? 'border-purple-500 text-purple-600'
                    : 'border-transparent text-gray-500 hover:text-gray-700'
                }`}
              >
                <tab.icon className="h-4 w-4" />
                <span>{tab.label}</span>
              </button>
            ))}
          </nav>
        </div>

        <div className="p-6">
          {activeTab === 'ideas' && (
            <div className="space-y-6">
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between space-y-4 sm:space-y-0">
                <div className="flex items-center space-x-4">
                  <div className="relative">
                    <Search className="h-4 w-4 absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" />
                    <input
                      type="text"
                      placeholder="Search ideas..."
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                      className="pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    />
                  </div>
                  <div className="flex items-center space-x-2">
                    <Filter className="h-4 w-4 text-gray-600" />
                    <select
                      value={filterCategory}
                      onChange={(e) => setFilterCategory(e.target.value)}
                      className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                    >
                      {categories.map(category => (
                        <option key={category} value={category}>
                          {category === 'all' ? 'All Categories' : category}
                        </option>
                      ))}
                    </select>
                  </div>
                </div>
                <button
                  onClick={() => setShowAddForm(true)}
                  className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-4 py-2 rounded-lg font-medium hover:from-purple-600 hover:to-pink-700 transition-all duration-200 flex items-center space-x-2"
                >
                  <Plus className="h-4 w-4" />
                  <span>Add Idea</span>
                </button>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {filteredIdeas.map((idea) => (
                  <div key={idea.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow duration-200">
                    <div className="flex items-start justify-between mb-4">
                      <div className="flex-1">
                        <h3 className="font-semibold text-gray-900 mb-2">{idea.title}</h3>
                        <p className="text-sm text-gray-600 mb-3 line-clamp-3">{idea.description}</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div className="flex items-center justify-between">
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${getStageColor(idea.stage)}`}>
                          {idea.stage}
                        </span>
                        <div className="flex items-center space-x-1">
                          <Star className="h-4 w-4 text-yellow-500" />
                          <span className="text-sm font-medium">{idea.viability}/10</span>
                        </div>
                      </div>

                      <div className="flex items-center justify-between text-sm text-gray-600">
                        <span>Team: {idea.teamSize} members</span>
                        <span className={`px-2 py-1 rounded text-xs ${getCompetitionColor(idea.competition)}`}>
                          {idea.competition} competition
                        </span>
                      </div>

                      <div className="text-sm text-gray-600">
                        <span className="font-medium">Target: </span>
                        {idea.targetCompanies.slice(0, 2).join(', ')}
                        {idea.targetCompanies.length > 2 && ` +${idea.targetCompanies.length - 2}`}
                      </div>

                      <div className="flex flex-wrap gap-1">
                        {idea.technologies.slice(0, 3).map((tech) => (
                          <span key={tech} className="bg-purple-50 text-purple-700 px-2 py-1 rounded text-xs">
                            {tech}
                          </span>
                        ))}
                        {idea.technologies.length > 3 && (
                          <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded text-xs">
                            +{idea.technologies.length - 3}
                          </span>
                        )}
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                        <span className="text-sm font-medium text-green-600">{idea.fundingGoal}</span>
                        <div className="flex space-x-2">
                          {idea.demoUrl && (
                            <a href={idea.demoUrl} target="_blank" rel="noopener noreferrer" className="text-purple-600 hover:text-purple-700">
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          )}
                          <button className="text-purple-600 hover:text-purple-700">
                            <Rocket className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}

          {activeTab === 'pitch' && (
            <div className="space-y-6">
              {!showPitchBuilder ? (
                <div className="text-center py-12">
                  <Target className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                  <h3 className="text-lg font-medium text-gray-900 mb-2">Pitch Deck Builder</h3>
                  <p className="text-gray-600 mb-6">
                    Create compelling pitch decks with structured slides including problem statement, solution, technologies, and more
                  </p>
                  <button 
                    onClick={() => setShowPitchBuilder(true)}
                    className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-6 py-3 rounded-lg font-medium hover:from-purple-600 hover:to-pink-700 transition-all duration-200"
                  >
                    Create Pitch Deck
                  </button>
                </div>
              ) : (
                <div className="space-y-6">
                  <div className="flex items-center justify-between">
                    <h3 className="text-lg font-semibold text-gray-900">Build Your Pitch Deck</h3>
                    <div className="flex space-x-2">
                      <button className="bg-green-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-green-600 transition-colors duration-200 flex items-center space-x-2">
                        <Download className="h-4 w-4" />
                        <span>Export PPT</span>
                      </button>
                      <button 
                        onClick={() => setShowPitchBuilder(false)}
                        className="bg-gray-500 text-white px-4 py-2 rounded-lg font-medium hover:bg-gray-600 transition-colors duration-200"
                      >
                        <X className="h-4 w-4" />
                      </button>
                    </div>
                  </div>

                  <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                    {pitchSlides.map((slide, index) => (
                      <div key={slide.id} className="bg-white border border-gray-200 rounded-lg p-6">
                        <div className="flex items-center justify-between mb-4">
                          <h4 className="font-medium text-gray-900">
                            {index + 1}. {slide.title}
                          </h4>
                          <div className="flex space-x-2">
                            <button className="text-blue-600 hover:text-blue-700">
                              <Edit className="h-4 w-4" />
                            </button>
                            <button className="text-red-600 hover:text-red-700">
                              <Trash2 className="h-4 w-4" />
                            </button>
                          </div>
                        </div>

                        <textarea
                          value={slide.content}
                          onChange={(e) => handleSlideContentChange(slide.id, e.target.value)}
                          placeholder={`Enter content for ${slide.title.toLowerCase()}...`}
                          className="w-full h-32 p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                        />

                        <div className="mt-4">
                          <label className="block text-sm font-medium text-gray-700 mb-2">
                            Upload Supporting File (PPT, PDF, Images)
                          </label>
                          <div className="border-2 border-dashed border-gray-300 rounded-lg p-4 text-center hover:border-purple-400 transition-colors duration-200">
                            <input
                              type="file"
                              accept=".ppt,.pptx,.pdf,.jpg,.jpeg,.png"
                              onChange={(e) => {
                                const file = e.target.files?.[0];
                                if (file) handleFileUpload(slide.id, file);
                              }}
                              className="hidden"
                              id={`file-${slide.id}`}
                            />
                            <label htmlFor={`file-${slide.id}`} className="cursor-pointer">
                              <Upload className="h-8 w-8 text-gray-400 mx-auto mb-2" />
                              <p className="text-sm text-gray-600">
                                {slide.file ? slide.file.name : 'Click to upload or drag and drop'}
                              </p>
                              <p className="text-xs text-gray-500">PPT, PDF, JPG, PNG up to 10MB</p>
                            </label>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <div className="bg-gradient-to-br from-blue-50 to-purple-50 border border-blue-200 rounded-lg p-6">
                  <h4 className="font-semibold text-blue-900 mb-2">Problem & Solution</h4>
                  <p className="text-sm text-blue-700">Define the problem you're solving and your unique solution</p>
                </div>
                <div className="bg-gradient-to-br from-green-50 to-blue-50 border border-green-200 rounded-lg p-6">
                  <h4 className="font-semibold text-green-900 mb-2">Market Opportunity</h4>
                  <p className="text-sm text-green-700">Showcase the market size and growth potential</p>
                </div>
                <div className="bg-gradient-to-br from-purple-50 to-pink-50 border border-purple-200 rounded-lg p-6">
                  <h4 className="font-semibold text-purple-900 mb-2">Business Model</h4>
                  <p className="text-sm text-purple-700">Explain how you'll generate revenue and scale</p>
                </div>
              </div>
            </div>
          )}

          {activeTab === 'investors' && (
            <div className="space-y-6">
              <div className="bg-blue-50 border border-blue-200 rounded-lg p-6">
                <h3 className="text-lg font-semibold text-blue-900 mb-4">💡 Tips for Finding & Impressing Investors</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                  {investorTips.map((tip, index) => (
                    <div key={index} className="bg-white rounded-lg p-4 border border-blue-100">
                      <div className="flex items-start space-x-3">
                        <div className="bg-blue-100 p-2 rounded-lg">
                          <tip.icon className="h-4 w-4 text-blue-600" />
                        </div>
                        <div>
                          <h4 className="font-medium text-gray-900 mb-1">{tip.title}</h4>
                          <p className="text-sm text-gray-600">{tip.description}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">Connect with Investors</h3>
                <div className="flex items-center space-x-2">
                  <Filter className="h-4 w-4 text-gray-600" />
                  <select className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-purple-500 focus:border-transparent">
                    <option>All Stages</option>
                    <option>Pre-Seed</option>
                    <option>Seed</option>
                    <option>Series A</option>
                    <option>Series B</option>
                  </select>
                </div>
              </div>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                {investors.map((investor) => (
                  <div key={investor.id} className="bg-white border border-gray-200 rounded-lg p-6 hover:shadow-lg transition-shadow duration-200">
                    <div className="flex items-start justify-between mb-4">
                      <div>
                        <h4 className="font-semibold text-gray-900">{investor.name}</h4>
                        <p className="text-sm text-gray-600">{investor.company}</p>
                        <p className="text-xs text-gray-500">{investor.location}</p>
                      </div>
                      <div className="text-right">
                        <p className="text-sm font-medium text-green-600">{investor.investmentRange}</p>
                        <p className="text-xs text-gray-500">{investor.stage.join(', ')}</p>
                      </div>
                    </div>

                    <div className="space-y-3">
                      <div>
                        <p className="text-sm font-medium text-gray-700 mb-1">Focus Areas:</p>
                        <div className="flex flex-wrap gap-1">
                          {investor.focusAreas.map((area) => (
                            <span key={area} className="bg-purple-50 text-purple-700 px-2 py-1 rounded text-xs">
                              {area}
                            </span>
                          ))}
                        </div>
                      </div>

                      <div>
                        <p className="text-sm font-medium text-gray-700 mb-1">Portfolio:</p>
                        <p className="text-sm text-gray-600">{investor.portfolio.slice(0, 3).join(', ')}</p>
                      </div>

                      <div className="flex items-center justify-between pt-3 border-t border-gray-100">
                        <button
                          onClick={() => handleEmailInvestor(investor)}
                          className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-4 py-2 rounded-lg text-sm font-medium hover:from-purple-600 hover:to-pink-700 transition-all duration-200 flex items-center space-x-2"
                        >
                          <Mail className="h-4 w-4" />
                          <span>Email</span>
                        </button>
                        <div className="flex space-x-2">
                          {investor.linkedIn && (
                            <a href={investor.linkedIn} target="_blank" rel="noopener noreferrer" className="text-blue-600 hover:text-blue-700">
                              <ExternalLink className="h-4 w-4" />
                            </a>
                          )}
                          <button className="text-gray-600 hover:text-gray-700">
                            <Building className="h-4 w-4" />
                          </button>
                        </div>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Email Modal */}
      {showEmailModal && selectedInvestor && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="p-6 border-b border-gray-200">
              <div className="flex items-center justify-between">
                <h3 className="text-lg font-semibold text-gray-900">
                  Email {selectedInvestor.name}
                </h3>
                <button
                  onClick={() => setShowEmailModal(false)}
                  className="text-gray-500 hover:text-gray-700"
                >
                  <X className="h-5 w-5" />
                </button>
              </div>
            </div>
            
            <div className="p-6 space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  To: {selectedInvestor.contactEmail}
                </label>
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Subject
                </label>
                <input
                  type="text"
                  value={emailSubject}
                  onChange={(e) => setEmailSubject(e.target.value)}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent"
                />
              </div>
              
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Message
                </label>
                <textarea
                  value={emailBody}
                  onChange={(e) => setEmailBody(e.target.value)}
                  rows={12}
                  className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-purple-500 focus:border-transparent resize-none"
                />
              </div>
              
              <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
                <div className="flex items-start space-x-2">
                  <AlertCircle className="h-5 w-5 text-yellow-600 mt-0.5" />
                  <div>
                    <h4 className="font-medium text-yellow-800">Email Tips</h4>
                    <ul className="text-sm text-yellow-700 mt-1 space-y-1">
                      <li>• Keep it concise and professional</li>
                      <li>• Mention specific reasons why you're reaching out to them</li>
                      <li>• Include key metrics and traction</li>
                      <li>• Attach your pitch deck or one-pager</li>
                    </ul>
                  </div>
                </div>
              </div>
            </div>
            
            <div className="p-6 border-t border-gray-200 flex justify-end space-x-3">
              <button
                onClick={() => setShowEmailModal(false)}
                className="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition-colors duration-200"
              >
                Cancel
              </button>
              <button
                onClick={sendEmail}
                className="bg-gradient-to-r from-purple-500 to-pink-600 text-white px-4 py-2 rounded-lg font-medium hover:from-purple-600 hover:to-pink-700 transition-all duration-200 flex items-center space-x-2"
              >
                <Send className="h-4 w-4" />
                <span>Send Email</span>
              </button>
            </div>
          </div>
        </div>
      )}

      <div className="bg-gradient-to-r from-orange-400 to-red-500 rounded-xl p-6 text-white">
        <h2 className="text-xl font-bold mb-2">🚀 Startup Success Tips</h2>
        <p className="text-orange-100">
          Focus on solving real problems, validate your ideas with potential customers, and build a strong team. 
          Remember: execution is everything!
        </p>
      </div>
    </div>
  );
};

export default StartupIdeasPage;