import React from 'react';
import { useData } from '../contexts/DataContext';
import { CheckCircle, Circle, BookOpen, Code, ExternalLink, Award } from 'lucide-react';

const LearningRoadmapPage: React.FC = () => {
  const { roadmapItems, toggleRoadmapItem, companies } = useData();

  const completedItems = roadmapItems.filter(item => item.completed).length;
  const totalItems = roadmapItems.length;
  const progressPercentage = totalItems > 0 ? Math.round((completedItems / totalItems) * 100) : 0;

  const groupedItems = roadmapItems.reduce((acc, item) => {
    const company = companies.find(c => c.id === item.companyId);
    const companyName = company?.name || 'Unknown Company';
    
    if (!acc[companyName]) {
      acc[companyName] = [];
    }
    acc[companyName].push(item);
    return acc;
  }, {} as Record<string, typeof roadmapItems>);

  if (totalItems === 0) {
    return (
      <div className="text-center py-12">
        <BookOpen className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-gray-900 mb-2">No learning roadmap yet</h2>
        <p className="text-gray-600 mb-6">
          Add companies to your list and create a roadmap to start learning!
        </p>
        <a
          href="/add-company"
          className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:from-blue-600 hover:to-purple-700 transition-all duration-200"
        >
          <span>Add Company</span>
        </a>
      </div>
    );
  }

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
        <div className="flex items-center justify-between mb-4">
          <div>
            <h1 className="text-2xl font-bold">Learning Roadmap</h1>
            <p className="text-blue-100">Track your progress towards your dream job</p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold">{progressPercentage}%</div>
            <div className="text-blue-100">Complete</div>
          </div>
        </div>
        
        <div className="bg-white/20 rounded-full h-3 mb-2">
          <div
            className="bg-white rounded-full h-3 transition-all duration-500"
            style={{ width: `${progressPercentage}%` }}
          ></div>
        </div>
        
        <div className="flex justify-between text-sm text-blue-100">
          <span>{completedItems} of {totalItems} completed</span>
          <span>{totalItems - completedItems} remaining</span>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        <div className="bg-white rounded-lg p-4 shadow-md border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="bg-blue-100 p-2 rounded-lg">
              <BookOpen className="h-6 w-6 text-blue-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{totalItems}</div>
              <div className="text-sm text-gray-600">Total Items</div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-md border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="bg-green-100 p-2 rounded-lg">
              <CheckCircle className="h-6 w-6 text-green-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{completedItems}</div>
              <div className="text-sm text-gray-600">Completed</div>
            </div>
          </div>
        </div>
        
        <div className="bg-white rounded-lg p-4 shadow-md border border-gray-100">
          <div className="flex items-center space-x-3">
            <div className="bg-purple-100 p-2 rounded-lg">
              <Award className="h-6 w-6 text-purple-600" />
            </div>
            <div>
              <div className="text-2xl font-bold text-gray-900">{Object.keys(groupedItems).length}</div>
              <div className="text-sm text-gray-600">Companies</div>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-6">
        {Object.entries(groupedItems).map(([companyName, items]) => (
          <div key={companyName} className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
            <div className="bg-gray-50 p-4 border-b border-gray-100">
              <h2 className="text-lg font-semibold text-gray-900">{companyName}</h2>
              <p className="text-sm text-gray-600">
                {items.filter(item => item.completed).length} of {items.length} completed
              </p>
            </div>
            
            <div className="p-4">
              <div className="space-y-4">
                {items.map((item, index) => (
                  <div key={item.id} className="flex items-start space-x-4">
                    <div className="flex-shrink-0 mt-1">
                      <div className="flex flex-col items-center">
                        <button
                          onClick={() => toggleRoadmapItem(item.id)}
                          className={`transition-colors duration-200 ${
                            item.completed ? 'text-green-600' : 'text-gray-400 hover:text-gray-600'
                          }`}
                        >
                          {item.completed ? (
                            <CheckCircle className="h-6 w-6" />
                          ) : (
                            <Circle className="h-6 w-6" />
                          )}
                        </button>
                        {index < items.length - 1 && (
                          <div className="w-0.5 h-8 bg-gray-200 mt-2"></div>
                        )}
                      </div>
                    </div>
                    
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center space-x-2 mb-2">
                        {item.type === 'technology' ? (
                          <Code className="h-4 w-4 text-blue-600" />
                        ) : (
                          <BookOpen className="h-4 w-4 text-purple-600" />
                        )}
                        <h3 className={`font-medium ${item.completed ? 'text-gray-500 line-through' : 'text-gray-900'}`}>
                          {item.title}
                        </h3>
                        <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                          item.type === 'technology' 
                            ? 'bg-blue-100 text-blue-800' 
                            : 'bg-purple-100 text-purple-800'
                        }`}>
                          {item.type}
                        </span>
                      </div>
                      
                      <p className={`text-sm mb-3 ${item.completed ? 'text-gray-400' : 'text-gray-600'}`}>
                        {item.description}
                      </p>
                      
                      {item.resources.length > 0 && (
                        <div className="space-y-2">
                          <p className="text-sm font-medium text-gray-700">Resources:</p>
                          {item.resources.map((resource, resourceIndex) => (
                            <div key={resourceIndex} className="flex items-center justify-between bg-gray-50 p-2 rounded-lg">
                              <div>
                                <span className="text-sm font-medium text-gray-900">{resource.title}</span>
                                <span className="text-xs text-gray-500 ml-2 capitalize">({resource.type})</span>
                              </div>
                              <a
                                href={resource.url}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="text-blue-600 hover:text-blue-700"
                              >
                                <ExternalLink className="h-4 w-4" />
                              </a>
                            </div>
                          ))}
                        </div>
                      )}
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default LearningRoadmapPage;