import React, { useState } from 'react';
import { useData } from '../contexts/DataContext';
import { FileText, CheckCircle, XCircle, ExternalLink, Filter } from 'lucide-react';

const ResumeTipsPage: React.FC = () => {
  const { companies } = useData();
  const [selectedCompany, setSelectedCompany] = useState<string>('all');

  const resumeTips = {
    dos: [
      {
        title: 'Use a clean, professional format',
        description: 'Keep your resume visually appealing with consistent formatting, proper spacing, and clear sections.',
        applicable: 'all'
      },
      {
        title: 'Quantify your achievements',
        description: 'Use numbers, percentages, and metrics to demonstrate your impact and accomplishments.',
        applicable: 'all'
      },
      {
        title: 'Tailor your resume for each application',
        description: 'Customize your resume to match the specific job requirements and company culture.',
        applicable: 'all'
      },
      {
        title: 'Include relevant technical skills',
        description: 'List programming languages, frameworks, and tools that match the job requirements.',
        applicable: 'technology'
      },
      {
        title: 'Highlight leadership experience',
        description: 'Showcase any team lead roles, project management, or mentoring experience.',
        applicable: 'all'
      },
      {
        title: 'Use action verbs',
        description: 'Start bullet points with strong action verbs like "developed," "implemented," "optimized."',
        applicable: 'all'
      }
    ],
    donts: [
      {
        title: 'Don\'t exceed 2 pages',
        description: 'Keep your resume concise and focused. Most recruiters spend only 6-10 seconds on initial screening.',
        applicable: 'all'
      },
      {
        title: 'Don\'t include personal information',
        description: 'Avoid photos, age, marital status, or other personal details that aren\'t relevant to the job.',
        applicable: 'all'
      },
      {
        title: 'Don\'t use generic descriptions',
        description: 'Avoid vague statements like "responsible for" or "worked on" without specific details.',
        applicable: 'all'
      },
      {
        title: 'Don\'t list every technology you\'ve touched',
        description: 'Focus on technologies you\'re proficient in and relevant to the role.',
        applicable: 'technology'
      },
      {
        title: 'Don\'t forget to proofread',
        description: 'Spelling and grammar errors can immediately disqualify your application.',
        applicable: 'all'
      }
    ]
  };

  const templates = [
    {
      name: 'Tech Resume Template',
      description: 'Clean, modern template perfect for software engineers and developers',
      url: 'https://docs.google.com/document/d/1example1',
      category: 'technology'
    },
    {
      name: 'Business Resume Template',
      description: 'Professional template for business and consulting roles',
      url: 'https://docs.google.com/document/d/1example2',
      category: 'business'
    },
    {
      name: 'Creative Resume Template',
      description: 'Visually appealing template for design and creative positions',
      url: 'https://docs.google.com/document/d/1example3',
      category: 'design'
    },
    {
      name: 'Academic Resume Template',
      description: 'Formal template for research and academic positions',
      url: 'https://docs.google.com/document/d/1example4',
      category: 'academic'
    }
  ];

  const filterTips = (tips: typeof resumeTips.dos, category: string) => {
    if (category === 'all') return tips;
    return tips.filter(tip => tip.applicable === 'all' || tip.applicable === category);
  };

  const getCompanyCategory = (companyName: string) => {
    const company = companies.find(c => c.name === companyName);
    if (!company) return 'all';
    
    const industryMap: Record<string, string> = {
      'Technology': 'technology',
      'Software': 'technology',
      'E-commerce': 'business',
      'Social Media': 'technology',
      'Entertainment': 'creative',
      'Finance': 'business',
      'Healthcare': 'business'
    };
    
    return industryMap[company.industry] || 'all';
  };

  const selectedCategory = selectedCompany === 'all' ? 'all' : getCompanyCategory(selectedCompany);

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-xl p-6 text-white">
        <h1 className="text-2xl font-bold mb-2">Resume Tips & Templates</h1>
        <p className="text-blue-100">
          Craft a compelling resume that gets you noticed by your dream companies
        </p>
      </div>

      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-xl font-semibold text-gray-900">Filter by Company</h2>
          <div className="flex items-center space-x-2">
            <Filter className="h-5 w-5 text-gray-600" />
            <select
              value={selectedCompany}
              onChange={(e) => setSelectedCompany(e.target.value)}
              className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
            >
              <option value="all">All Companies</option>
              {companies.map((company) => (
                <option key={company.id} value={company.name}>
                  {company.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {selectedCompany !== 'all' && (
          <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-6">
            <p className="text-blue-800">
              Showing tips tailored for{' '}
              <span className="font-semibold">{selectedCompany}</span> and similar companies
            </p>
          </div>
        )}
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          <div className="bg-green-50 border-b border-green-200 p-4">
            <div className="flex items-center space-x-2">
              <CheckCircle className="h-6 w-6 text-green-600" />
              <h2 className="text-xl font-semibold text-green-900">Resume Do's</h2>
            </div>
          </div>
          <div className="p-4">
            <div className="space-y-4">
              {filterTips(resumeTips.dos, selectedCategory).map((tip, index) => (
                <div key={index} className="border-l-4 border-green-400 pl-4">
                  <h3 className="font-medium text-gray-900 mb-1">{tip.title}</h3>
                  <p className="text-sm text-gray-600">{tip.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>

        <div className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
          <div className="bg-red-50 border-b border-red-200 p-4">
            <div className="flex items-center space-x-2">
              <XCircle className="h-6 w-6 text-red-600" />
              <h2 className="text-xl font-semibold text-red-900">Resume Don'ts</h2>
            </div>
          </div>
          <div className="p-4">
            <div className="space-y-4">
              {filterTips(resumeTips.donts, selectedCategory).map((tip, index) => (
                <div key={index} className="border-l-4 border-red-400 pl-4">
                  <h3 className="font-medium text-gray-900 mb-1">{tip.title}</h3>
                  <p className="text-sm text-gray-600">{tip.description}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-md border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <div className="flex items-center space-x-2 mb-2">
            <FileText className="h-6 w-6 text-blue-600" />
            <h2 className="text-xl font-semibold text-gray-900">Resume Templates</h2>
          </div>
          <p className="text-gray-600">
            Choose from our collection of professional resume templates
          </p>
        </div>
        <div className="p-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {templates.map((template, index) => (
              <div key={index} className="border border-gray-200 rounded-lg p-4 hover:shadow-md transition-shadow duration-200">
                <div className="flex items-center justify-between mb-3">
                  <h3 className="font-medium text-gray-900">{template.name}</h3>
                  <a
                    href={template.url}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-blue-600 hover:text-blue-700"
                  >
                    <ExternalLink className="h-5 w-5" />
                  </a>
                </div>
                <p className="text-sm text-gray-600 mb-3">{template.description}</p>
                <span className="inline-block bg-blue-100 text-blue-800 px-2 py-1 rounded-full text-xs font-medium capitalize">
                  {template.category}
                </span>
              </div>
            ))}
          </div>
        </div>
      </div>

      <div className="bg-gradient-to-r from-yellow-400 to-orange-500 rounded-xl p-6 text-white">
        <h2 className="text-xl font-bold mb-2">Pro Tip</h2>
        <p className="text-yellow-100">
          Remember to update your resume regularly and keep multiple versions tailored to different types of roles.
          Always save your resume as a PDF to preserve formatting across different systems.
        </p>
      </div>
    </div>
  );
};

export default ResumeTipsPage;