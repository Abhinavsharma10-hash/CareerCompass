import React, { useState } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useData } from '../contexts/DataContext';
import { 
  Building, 
  MapPin, 
  Users, 
  Code, 
  BookOpen, 
  Briefcase, 
  TrendingUp,
  ChevronDown,
  ChevronUp,
  ExternalLink,
  Plus,
  Calendar,
  Award,
  Clock,
  Target,
  History,
  Lightbulb,
  CheckCircle
} from 'lucide-react';

const CompanyProfilePage: React.FC = () => {
  const { id } = useParams<{ id: string }>();
  const navigate = useNavigate();
  const { companies, addToRoadmap } = useData();
  const [expandedSections, setExpandedSections] = useState<Set<string>>(new Set(['overview']));

  const company = companies.find(c => c.id === id);

  if (!company) {
    return (
      <div className="text-center py-12">
        <Building className="h-12 w-12 text-gray-400 mx-auto mb-4" />
        <h2 className="text-xl font-semibold text-gray-900 mb-2">Company not found</h2>
        <button
          onClick={() => navigate('/')}
          className="text-blue-600 hover:text-blue-700"
        >
          Back to Dashboard
        </button>
      </div>
    );
  }

  const toggleSection = (section: string) => {
    const newExpanded = new Set(expandedSections);
    if (newExpanded.has(section)) {
      newExpanded.delete(section);
    } else {
      newExpanded.add(section);
    }
    setExpandedSections(newExpanded);
  };

  const handleAddToRoadmap = () => {
    addToRoadmap(company.id);
    navigate('/roadmap');
  };

  const getUrgencyColor = (urgency: string) => {
    switch (urgency) {
      case 'high': return 'bg-red-100 text-red-800 border-red-200';
      case 'medium': return 'bg-yellow-100 text-yellow-800 border-yellow-200';
      case 'low': return 'bg-green-100 text-green-800 border-green-200';
      default: return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  const sections = [
    {
      id: 'overview',
      title: 'Company Overview',
      icon: Building,
      content: (
        <div className="space-y-4">
          <p className="text-gray-700 leading-relaxed">{company.overview}</p>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Building className="h-5 w-5 text-blue-600" />
                <span className="font-medium text-blue-900">Industry</span>
              </div>
              <p className="text-blue-700">{company.industry}</p>
            </div>
            <div className="bg-green-50 p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <MapPin className="h-5 w-5 text-green-600" />
                <span className="font-medium text-green-900">Location</span>
              </div>
              <p className="text-green-700">{company.location}</p>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg">
              <div className="flex items-center space-x-2 mb-2">
                <Users className="h-5 w-5 text-purple-600" />
                <span className="font-medium text-purple-900">Fresher Roles</span>
              </div>
              <p className="text-purple-700">{company.jobRoles.length} positions</p>
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'history',
      title: 'Company History & Leadership',
      icon: History,
      content: (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="bg-blue-50 p-4 rounded-lg">
              <h4 className="font-semibold text-blue-900 mb-2">Company Details</h4>
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-blue-700">Established:</span>
                  <span className="font-medium text-blue-900">{company.companyHistory.established}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-700">Current CEO:</span>
                  <span className="font-medium text-blue-900">{company.companyHistory.currentCEO}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-blue-700">Focus Area:</span>
                  <span className="font-medium text-blue-900">{company.companyHistory.focusDepartment}</span>
                </div>
              </div>
            </div>
            
            <div className="bg-green-50 p-4 rounded-lg">
              <h4 className="font-semibold text-green-900 mb-2">Fresher Support</h4>
              <ul className="space-y-1">
                {company.companyHistory.fresherSupport.map((support, index) => (
                  <li key={index} className="flex items-start space-x-2 text-green-700">
                    <CheckCircle className="h-4 w-4 mt-0.5 flex-shrink-0" />
                    <span className="text-sm">{support}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
          
          <div>
            <h4 className="font-semibold text-gray-900 mb-3">Key Milestones</h4>
            <div className="space-y-3">
              {company.companyHistory.keyMilestones.map((milestone, index) => (
                <div key={index} className="flex items-start space-x-3">
                  <div className="w-2 h-2 bg-blue-500 rounded-full mt-2"></div>
                  <p className="text-gray-700">{milestone}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'services',
      title: 'Services & Products',
      icon: Briefcase,
      content: (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {company.services.map((service, index) => (
            <div key={index} className="bg-gray-50 p-4 rounded-lg">
              <div className="flex items-center space-x-2">
                <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                <span className="font-medium text-gray-900">{service}</span>
              </div>
            </div>
          ))}
        </div>
      )
    },
    {
      id: 'skills',
      title: 'Skills Required',
      icon: Users,
      content: (
        <div className="flex flex-wrap gap-3">
          {company.skillsRequired.map((skill, index) => (
            <span
              key={index}
              className="bg-gradient-to-r from-blue-500 to-purple-600 text-white px-4 py-2 rounded-full text-sm font-medium"
            >
              {skill}
            </span>
          ))}
        </div>
      )
    },
    {
      id: 'tech',
      title: 'Tech Stack',
      icon: Code,
      content: (
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4">
          {company.techStack.map((tech, index) => (
            <div key={index} className="bg-white border border-gray-200 p-4 rounded-lg hover:shadow-md transition-shadow duration-200">
              <div className="text-center">
                <Code className="h-8 w-8 text-blue-600 mx-auto mb-2" />
                <span className="font-medium text-gray-900">{tech}</span>
              </div>
            </div>
          ))}
        </div>
      )
    },
    {
      id: 'projects',
      title: 'Projects for Freshers',
      icon: Lightbulb,
      content: (
        <div className="space-y-6">
          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Beginner Projects</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {company.projectsForFreshers.beginner.map((project, index) => (
                <div key={index} className="bg-green-50 border border-green-200 p-4 rounded-lg">
                  <h5 className="font-medium text-green-900 mb-2">{project.title}</h5>
                  <p className="text-sm text-green-700 mb-3">{project.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex flex-wrap gap-1">
                      {project.technologies.map((tech, techIndex) => (
                        <span key={techIndex} className="bg-green-100 text-green-800 px-2 py-1 rounded text-xs">
                          {tech}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center text-xs text-green-600">
                      <Clock className="h-3 w-3 mr-1" />
                      {project.estimatedTime}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Intermediate Projects</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {company.projectsForFreshers.intermediate.map((project, index) => (
                <div key={index} className="bg-blue-50 border border-blue-200 p-4 rounded-lg">
                  <h5 className="font-medium text-blue-900 mb-2">{project.title}</h5>
                  <p className="text-sm text-blue-700 mb-3">{project.description}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex flex-wrap gap-1">
                      {project.technologies.map((tech, techIndex) => (
                        <span key={techIndex} className="bg-blue-100 text-blue-800 px-2 py-1 rounded text-xs">
                          {tech}
                        </span>
                      ))}
                    </div>
                    <div className="flex items-center text-xs text-blue-600">
                      <Clock className="h-3 w-3 mr-1" />
                      {project.estimatedTime}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Recommended Certifications</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {company.projectsForFreshers.certifications.map((cert, index) => (
                <div key={index} className="bg-purple-50 border border-purple-200 p-4 rounded-lg">
                  <div className="flex items-start justify-between mb-2">
                    <h5 className="font-medium text-purple-900">{cert.title}</h5>
                    <a
                      href={cert.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-purple-600 hover:text-purple-700"
                    >
                      <ExternalLink className="h-4 w-4" />
                    </a>
                  </div>
                  <p className="text-sm text-purple-700 mb-2">by {cert.provider}</p>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center text-xs text-purple-600">
                      <Clock className="h-3 w-3 mr-1" />
                      {cert.duration}
                    </div>
                    <span className={`px-2 py-1 rounded text-xs font-medium ${
                      cert.isFree ? 'bg-green-100 text-green-800' : 'bg-orange-100 text-orange-800'
                    }`}>
                      {cert.isFree ? 'Free' : 'Paid'}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )
    },
    {
      id: 'learning',
      title: 'Learning Resources',
      icon: BookOpen,
      content: (
        <div className="space-y-4">
          {company.learningResources.map((resource, index) => (
            <div key={index} className="bg-white border border-gray-200 p-4 rounded-lg hover:shadow-md transition-shadow duration-200">
              <div className="flex items-center justify-between">
                <div>
                  <h4 className="font-medium text-gray-900">{resource.title}</h4>
                  <p className="text-sm text-gray-600 capitalize">{resource.type}</p>
                </div>
                <a
                  href={resource.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="text-blue-600 hover:text-blue-700"
                >
                  <ExternalLink className="h-5 w-5" />
                </a>
              </div>
            </div>
          ))}
        </div>
      )
    },
    {
      id: 'internship',
      title: 'Internship & Workshop Details',
      icon: Briefcase,
      content: (
        <div className="space-y-4">
          <div className="bg-green-50 border border-green-200 p-4 rounded-lg">
            <div className="flex items-center space-x-2 mb-2">
              <div className={`w-3 h-3 rounded-full ${company.internshipDetails.available ? 'bg-green-500' : 'bg-red-500'}`}></div>
              <span className="font-medium text-gray-900">
                {company.internshipDetails.available ? 'Internships Available' : 'No Current Openings'}
              </span>
            </div>
            {company.internshipDetails.available && (
              <div className="space-y-2">
                <p className="text-sm text-gray-600">
                  <strong>Duration:</strong> {company.internshipDetails.duration}
                </p>
                <div>
                  <p className="text-sm font-medium text-gray-900 mb-1">Requirements:</p>
                  <ul className="text-sm text-gray-600 space-y-1">
                    {company.internshipDetails.requirements.map((req, index) => (
                      <li key={index} className="flex items-start space-x-2">
                        <div className="w-1.5 h-1.5 bg-gray-400 rounded-full mt-2"></div>
                        <span>{req}</span>
                      </li>
                    ))}
                  </ul>
                </div>
              </div>
            )}
          </div>
        </div>
      )
    },
    {
      id: 'roles',
      title: 'Fresher Job Roles',
      icon: Users,
      content: (
        <div className="space-y-4">
          {company.jobRoles.map((role, index) => (
            <div key={index} className="bg-white border border-gray-200 p-4 rounded-lg">
              <div className="flex justify-between items-start mb-2">
                <h4 className="font-medium text-gray-900">{role.title}</h4>
                <span className="bg-green-100 text-green-800 px-2 py-1 rounded-md text-sm">
                  {role.salary}
                </span>
              </div>
              <p className="text-sm text-gray-600">Experience: {role.experience}</p>
            </div>
          ))}
        </div>
      )
    },
    {
      id: 'stats',
      title: 'Hiring Statistics',
      icon: TrendingUp,
      content: (
        <div className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-blue-50 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-blue-600">{company.hiringStats.totalHires}</div>
              <div className="text-sm text-blue-800">Total Hires</div>
            </div>
            <div className="bg-green-50 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-green-600">{company.hiringStats.internshipConversions}%</div>
              <div className="text-sm text-green-800">Internship Conversions</div>
            </div>
            <div className="bg-purple-50 p-4 rounded-lg text-center">
              <div className="text-2xl font-bold text-purple-600">{company.hiringStats.averagePackage}</div>
              <div className="text-sm text-purple-800">Average Package</div>
            </div>
          </div>

          <div>
            <h4 className="text-lg font-semibold text-gray-900 mb-4">Active Hiring Departments</h4>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {company.hiringStats.hiringDepartments.map((dept, index) => (
                <div key={index} className="bg-white border border-gray-200 p-4 rounded-lg">
                  <div className="flex items-center justify-between mb-2">
                    <h5 className="font-medium text-gray-900">{dept.department}</h5>
                    <span className={`px-2 py-1 rounded-full text-xs font-medium border ${getUrgencyColor(dept.urgency)}`}>
                      {dept.urgency} priority
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Target className="h-4 w-4 text-gray-500" />
                    <span className="text-sm text-gray-600">{dept.openings} openings</span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )
    }
  ];

  return (
    <div className="max-w-4xl mx-auto space-y-6">
      <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center space-x-4">
            <img
              src={company.logo}
              alt={`${company.name} logo`}
              className="w-16 h-16 rounded-lg object-cover"
            />
            <div>
              <h1 className="text-3xl font-bold text-gray-900">{company.name}</h1>
              <p className="text-gray-600">{company.industry} • {company.location}</p>
            </div>
          </div>
          <button
            onClick={handleAddToRoadmap}
            className="bg-gradient-to-r from-green-500 to-blue-600 text-white px-6 py-3 rounded-lg font-medium hover:from-green-600 hover:to-blue-700 transition-all duration-200 flex items-center space-x-2"
          >
            <Plus className="h-5 w-5" />
            <span>Add to Roadmap</span>
          </button>
        </div>
      </div>

      <div className="space-y-4">
        {sections.map((section) => (
          <div key={section.id} className="bg-white rounded-xl shadow-md border border-gray-100 overflow-hidden">
            <button
              onClick={() => toggleSection(section.id)}
              className="w-full p-6 text-left hover:bg-gray-50 transition-colors duration-200"
            >
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <section.icon className="h-6 w-6 text-blue-600" />
                  <h2 className="text-xl font-semibold text-gray-900">{section.title}</h2>
                </div>
                {expandedSections.has(section.id) ? (
                  <ChevronUp className="h-5 w-5 text-gray-500" />
                ) : (
                  <ChevronDown className="h-5 w-5 text-gray-500" />
                )}
              </div>
            </button>
            
            {expandedSections.has(section.id) && (
              <div className="px-6 pb-6 border-t border-gray-100">
                <div className="pt-4">
                  {section.content}
                </div>
              </div>
            )}
          </div>
        ))}
      </div>
    </div>
  );
};

export default CompanyProfilePage;