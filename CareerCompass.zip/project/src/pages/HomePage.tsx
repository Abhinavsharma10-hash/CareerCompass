import React from 'react';
import { Link } from 'react-router-dom';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { Plus, Building, MapPin, Users, TrendingUp, Target, Zap, Lightbulb } from 'lucide-react';

const HomePage: React.FC = () => {
  const { user } = useAuth();
  const { companies, userRequirements, autoApplications } = useData();

  const pendingApplications = autoApplications.filter(app => app.status === 'pending').length;

  return (
    <div className="space-y-8">
      <div className="bg-gradient-to-r from-blue-500 to-purple-600 rounded-2xl p-8 text-white">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold mb-2">
              Welcome to Career Compass, {user?.name?.split(' ')[0] || 'User'}! 🧭
            </h1>
            <p className="text-blue-100 text-lg">
              Your AI-powered dream company management platform is ready to navigate your journey
            </p>
          </div>
          <div className="hidden md:block">
            <div className="bg-white/20 backdrop-blur-sm rounded-lg p-4">
              <div className="text-center">
                <div className="text-2xl font-bold">{companies.length}</div>
                <div className="text-sm text-blue-100">Companies Tracked</div>
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
        <Link
          to="/add-company"
          className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-all duration-200 border border-gray-100 hover:border-blue-200 group"
        >
          <div className="flex items-center space-x-4">
            <div className="bg-gradient-to-r from-green-400 to-blue-500 p-3 rounded-lg group-hover:scale-110 transition-transform duration-200">
              <Plus className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Add Company</h3>
              <p className="text-gray-600">Track your target companies</p>
            </div>
          </div>
        </Link>

        <Link
          to="/requirements"
          className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-all duration-200 border border-gray-100 hover:border-purple-200 group"
        >
          <div className="flex items-center space-x-4">
            <div className="bg-gradient-to-r from-purple-400 to-pink-500 p-3 rounded-lg group-hover:scale-110 transition-transform duration-200">
              <Target className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Set Requirements</h3>
              <p className="text-gray-600">Define your career goals</p>
            </div>
          </div>
        </Link>

        <Link
          to="/auto-applications"
          className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-all duration-200 border border-gray-100 hover:border-green-200 group relative"
        >
          <div className="flex items-center space-x-4">
            <div className="bg-gradient-to-r from-orange-400 to-red-500 p-3 rounded-lg group-hover:scale-110 transition-transform duration-200">
              <Zap className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Auto Applications</h3>
              <p className="text-gray-600">AI-powered job matching</p>
            </div>
          </div>
          {pendingApplications > 0 && (
            <div className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-6 w-6 flex items-center justify-center">
              {pendingApplications}
            </div>
          )}
        </Link>

        <Link
          to="/startup-ideas"
          className="bg-white rounded-xl shadow-md p-6 hover:shadow-lg transition-all duration-200 border border-gray-100 hover:border-yellow-200 group"
        >
          <div className="flex items-center space-x-4">
            <div className="bg-gradient-to-r from-yellow-400 to-orange-500 p-3 rounded-lg group-hover:scale-110 transition-transform duration-200">
              <Lightbulb className="h-6 w-6 text-white" />
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-900">Startup Ideas</h3>
              <p className="text-gray-600">Build & pitch your ideas</p>
            </div>
          </div>
        </Link>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2 bg-white rounded-xl shadow-md border border-gray-100">
          <div className="p-6 border-b border-gray-100">
            <h2 className="text-2xl font-bold text-gray-900">Your Companies</h2>
            <p className="text-gray-600 mt-1">
              {companies.length === 0 
                ? 'No companies added yet. Start building your target list!' 
                : `${companies.length} compan${companies.length === 1 ? 'y' : 'ies'} in your list`}
            </p>
          </div>

          <div className="p-6">
            {companies.length === 0 ? (
              <div className="text-center py-12">
                <div className="bg-gray-100 rounded-full p-4 w-16 h-16 mx-auto mb-4">
                  <Building className="h-8 w-8 text-gray-400" />
                </div>
                <h3 className="text-lg font-medium text-gray-900 mb-2">No companies yet</h3>
                <p className="text-gray-600 mb-6">
                  Add companies to start getting personalized career guidance
                </p>
                <Link
                  to="/add-company"
                  className="inline-flex items-center space-x-2 bg-gradient-to-r from-blue-500 to-purple-600 text-white px-6 py-3 rounded-lg font-medium hover:from-blue-600 hover:to-purple-700 transition-all duration-200"
                >
                  <Plus className="h-5 w-5" />
                  <span>Add Company</span>
                </Link>
              </div>
            ) : (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                {companies.slice(0, 4).map((company) => (
                  <Link
                    key={company.id}
                    to={`/company/${company.id}`}
                    className="group"
                  >
                    <div className="bg-white border border-gray-200 rounded-lg p-4 hover:shadow-lg hover:border-blue-300 transition-all duration-200 group-hover:scale-105">
                      <div className="flex items-center space-x-3 mb-3">
                        <img
                          src={company.logo}
                          alt={`${company.name} logo`}
                          className="w-10 h-10 rounded-lg object-cover"
                        />
                        <div>
                          <h3 className="font-semibold text-gray-900 group-hover:text-blue-600">
                            {company.name}
                          </h3>
                          <p className="text-sm text-gray-600">{company.industry}</p>
                        </div>
                      </div>
                      
                      <div className="space-y-1">
                        <div className="flex items-center text-sm text-gray-600">
                          <MapPin className="h-3 w-3 mr-2" />
                          {company.location}
                        </div>
                        <div className="flex items-center text-sm text-gray-600">
                          <Users className="h-3 w-3 mr-2" />
                          {company.jobRoles.length} roles
                        </div>
                      </div>

                      <div className="mt-3 flex flex-wrap gap-1">
                        {company.techStack.slice(0, 2).map((tech) => (
                          <span
                            key={tech}
                            className="bg-blue-50 text-blue-700 px-2 py-1 rounded-md text-xs font-medium"
                          >
                            {tech}
                          </span>
                        ))}
                        {company.techStack.length > 2 && (
                          <span className="bg-gray-100 text-gray-600 px-2 py-1 rounded-md text-xs">
                            +{company.techStack.length - 2}
                          </span>
                        )}
                      </div>
                    </div>
                  </Link>
                ))}
                {companies.length > 4 && (
                  <Link
                    to="/"
                    className="border-2 border-dashed border-gray-300 rounded-lg p-4 flex items-center justify-center text-gray-500 hover:border-blue-400 hover:text-blue-600 transition-colors duration-200"
                  >
                    <div className="text-center">
                      <Plus className="h-6 w-6 mx-auto mb-2" />
                      <span className="text-sm font-medium">View All ({companies.length})</span>
                    </div>
                  </Link>
                )}
              </div>
            )}
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-white rounded-xl shadow-md border border-gray-100 p-6">
            <h3 className="text-lg font-semibold text-gray-900 mb-4">Quick Stats</h3>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Companies</span>
                <span className="font-semibold text-blue-600">{companies.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Requirements</span>
                <span className="font-semibold text-purple-600">{userRequirements.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Opportunities</span>
                <span className="font-semibold text-green-600">{autoApplications.length}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-gray-600">Pending Apps</span>
                <span className="font-semibold text-orange-600">{pendingApplications}</span>
              </div>
            </div>
          </div>

          <div className="bg-gradient-to-r from-green-400 to-blue-500 rounded-xl p-6 text-white">
            <h3 className="text-lg font-bold mb-2">🤖 AI Assistant</h3>
            <p className="text-green-100 text-sm mb-4">
              Get personalized career advice and guidance from our AI chatbot
            </p>
            <div className="text-xs text-green-200">
              Click the chat icon in the bottom right to get started!
            </div>
          </div>

          <div className="bg-gradient-to-r from-purple-400 to-pink-500 rounded-xl p-6 text-white">
            <h3 className="text-lg font-bold mb-2">💡 Startup Hub</h3>
            <p className="text-purple-100 text-sm mb-4">
              Build innovative ideas, create pitch decks, and connect with investors
            </p>
            <Link
              to="/startup-ideas"
              className="text-xs text-purple-200 hover:text-white transition-colors duration-200"
            >
              Explore startup opportunities →
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};

export default HomePage;