import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { useData } from '../contexts/DataContext';
import { Building, Plus, X } from 'lucide-react';

const predefinedCompanies = [
  {
    name: 'Google',
    logo: 'https://images.pexels.com/photos/270360/pexels-photo-270360.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Technology',
    location: 'Mountain View, CA'
  },
  {
    name: 'Microsoft',
    logo: 'https://images.pexels.com/photos/159304/network-cable-ethernet-computer-159304.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Technology',
    location: 'Redmond, WA'
  },
  {
    name: 'Apple',
    logo: 'https://images.pexels.com/photos/18105/pexels-photo.jpg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Technology',
    location: 'Cupertino, CA'
  },
  {
    name: 'Amazon',
    logo: 'https://images.pexels.com/photos/230544/pexels-photo-230544.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'E-commerce',
    location: 'Seattle, WA'
  },
  {
    name: 'Meta',
    logo: 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Social Media',
    location: 'Menlo Park, CA'
  },
  {
    name: 'Netflix',
    logo: 'https://images.pexels.com/photos/265685/pexels-photo-265685.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Entertainment',
    location: 'Los Gatos, CA'
  },
  {
    name: 'Tesla',
    logo: 'https://images.pexels.com/photos/120049/pexels-photo-120049.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Automotive',
    location: 'Austin, TX'
  },
  {
    name: 'Spotify',
    logo: 'https://images.pexels.com/photos/1763075/pexels-photo-1763075.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Music Streaming',
    location: 'Stockholm, Sweden'
  },
  {
    name: 'Uber',
    logo: 'https://images.pexels.com/photos/1118448/pexels-photo-1118448.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Transportation',
    location: 'San Francisco, CA'
  },
  {
    name: 'Airbnb',
    logo: 'https://images.pexels.com/photos/271816/pexels-photo-271816.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Hospitality',
    location: 'San Francisco, CA'
  },
  {
    name: 'Adobe',
    logo: 'https://images.pexels.com/photos/196644/pexels-photo-196644.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Software',
    location: 'San Jose, CA'
  },
  {
    name: 'Salesforce',
    logo: 'https://images.pexels.com/photos/3184418/pexels-photo-3184418.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Cloud Computing',
    location: 'San Francisco, CA'
  },
  {
    name: 'IBM',
    logo: 'https://images.pexels.com/photos/442150/pexels-photo-442150.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Technology',
    location: 'Armonk, NY'
  },
  {
    name: 'Oracle',
    logo: 'https://images.pexels.com/photos/1181467/pexels-photo-1181467.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Database Software',
    location: 'Austin, TX'
  },
  {
    name: 'Nvidia',
    logo: 'https://images.pexels.com/photos/2582937/pexels-photo-2582937.jpeg?auto=compress&cs=tinysrgb&w=400',
    industry: 'Graphics Technology',
    location: 'Santa Clara, CA'
  }
];

const AddCompanyPage: React.FC = () => {
  const navigate = useNavigate();
  const { addCompany } = useData();
  
  const [isCustom, setIsCustom] = useState(false);
  const [selectedCompany, setSelectedCompany] = useState<string>('');
  const [customCompany, setCustomCompany] = useState({
    name: '',
    logo: '',
    industry: '',
    location: ''
  });
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);

    try {
      let companyData;
      
      if (isCustom) {
        companyData = {
          ...customCompany,
          logo: customCompany.logo || 'https://images.pexels.com/photos/267350/pexels-photo-267350.jpeg?auto=compress&cs=tinysrgb&w=400'
        };
      } else {
        const selected = predefinedCompanies.find(c => c.name === selectedCompany);
        if (!selected) return;
        companyData = selected;
      }

      const fullCompanyData = {
        ...companyData,
        overview: `${companyData.name} is a leading company in the ${companyData.industry.toLowerCase()} industry, known for innovation and excellence. They offer excellent opportunities for freshers to grow and learn.`,
        services: [
          'Software Development',
          'Cloud Services',
          'Data Analytics',
          'Artificial Intelligence'
        ]
      };

      addCompany(fullCompanyData);
      navigate('/');
    } catch (error) {
      console.error('Error adding company:', error);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-4xl mx-auto">
      <div className="bg-white rounded-xl shadow-md border border-gray-100">
        <div className="p-6 border-b border-gray-100">
          <h1 className="text-2xl font-bold text-gray-900">Add Target Company</h1>
          <p className="text-gray-600 mt-1">
            Choose from 15+ popular companies or add a custom one
          </p>
        </div>

        <div className="p-6">
          <div className="flex space-x-4 mb-6">
            <button
              onClick={() => setIsCustom(false)}
              className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
                !isCustom
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Popular Companies
            </button>
            <button
              onClick={() => setIsCustom(true)}
              className={`flex-1 py-3 px-4 rounded-lg font-medium transition-all duration-200 ${
                isCustom
                  ? 'bg-gradient-to-r from-blue-500 to-purple-600 text-white'
                  : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
              }`}
            >
              Custom Company
            </button>
          </div>

          <form onSubmit={handleSubmit} className="space-y-6">
            {!isCustom ? (
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-3">
                  Select Company
                </label>
                <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                  {predefinedCompanies.map((company) => (
                    <div
                      key={company.name}
                      onClick={() => setSelectedCompany(company.name)}
                      className={`cursor-pointer border rounded-lg p-4 transition-all duration-200 ${
                        selectedCompany === company.name
                          ? 'border-blue-500 bg-blue-50 ring-2 ring-blue-200'
                          : 'border-gray-200 hover:border-gray-300 hover:shadow-md'
                      }`}
                    >
                      <div className="flex items-center space-x-3">
                        <img
                          src={company.logo}
                          alt={`${company.name} logo`}
                          className="w-12 h-12 rounded-lg object-cover"
                        />
                        <div className="flex-1 min-w-0">
                          <h3 className="font-medium text-gray-900 truncate">{company.name}</h3>
                          <p className="text-sm text-gray-600 truncate">{company.industry}</p>
                          <p className="text-xs text-gray-500 truncate">{company.location}</p>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                <div>
                  <label htmlFor="company-name" className="block text-sm font-medium text-gray-700 mb-2">
                    Company Name
                  </label>
                  <input
                    type="text"
                    id="company-name"
                    value={customCompany.name}
                    onChange={(e) => setCustomCompany({...customCompany, name: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter company name"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="industry" className="block text-sm font-medium text-gray-700 mb-2">
                    Industry
                  </label>
                  <input
                    type="text"
                    id="industry"
                    value={customCompany.industry}
                    onChange={(e) => setCustomCompany({...customCompany, industry: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., Technology, Healthcare, Finance"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                    Location
                  </label>
                  <input
                    type="text"
                    id="location"
                    value={customCompany.location}
                    onChange={(e) => setCustomCompany({...customCompany, location: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="e.g., San Francisco, CA"
                    required
                  />
                </div>

                <div>
                  <label htmlFor="logo" className="block text-sm font-medium text-gray-700 mb-2">
                    Logo URL (Optional)
                  </label>
                  <input
                    type="url"
                    id="logo"
                    value={customCompany.logo}
                    onChange={(e) => setCustomCompany({...customCompany, logo: e.target.value})}
                    className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="https://example.com/logo.png"
                  />
                </div>
              </div>
            )}

            <div className="flex space-x-4 pt-4">
              <button
                type="button"
                onClick={() => navigate('/')}
                className="flex-1 py-3 px-4 border border-gray-300 rounded-lg text-gray-700 font-medium hover:bg-gray-50 transition-colors duration-200"
              >
                Cancel
              </button>
              <button
                type="submit"
                disabled={loading || (!isCustom && !selectedCompany) || (isCustom && !customCompany.name)}
                className="flex-1 bg-gradient-to-r from-blue-500 to-purple-600 text-white py-3 px-4 rounded-lg font-medium hover:from-blue-600 hover:to-purple-700 disabled:opacity-50 transition-all duration-200"
              >
                {loading ? 'Adding...' : 'Add Company'}
              </button>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
};

export default AddCompanyPage;