import React, { createContext, useContext, useState, useEffect } from 'react';

interface User {
  id: string;
  email: string;
  name: string;
  isGuest: boolean;
}

interface AuthContextType {
  user: User | null;
  login: (email: string, password: string) => Promise<boolean>;
  signup: (email: string, password: string, name: string) => Promise<boolean>;
  loginAsGuest: () => void;
  logout: () => void;
  isAuthenticated: boolean;
}

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (context === undefined) {
    throw new Error('useAuth must be used within an AuthProvider');
  }
  return context;
};

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);

  useEffect(() => {
    const savedUser = localStorage.getItem('careerpath_user');
    if (savedUser) {
      setUser(JSON.parse(savedUser));
    }
  }, []);

  const login = async (email: string, password: string): Promise<boolean> => {
    // Simulate API call
    const savedUsers = JSON.parse(localStorage.getItem('careerpath_users') || '[]');
    const existingUser = savedUsers.find((u: any) => u.email === email && u.password === password);
    
    if (existingUser) {
      const userObj = {
        id: existingUser.id,
        email: existingUser.email,
        name: existingUser.name,
        isGuest: false
      };
      setUser(userObj);
      localStorage.setItem('careerpath_user', JSON.stringify(userObj));
      return true;
    }
    return false;
  };

  const signup = async (email: string, password: string, name: string): Promise<boolean> => {
    // Simulate API call
    const savedUsers = JSON.parse(localStorage.getItem('careerpath_users') || '[]');
    const existingUser = savedUsers.find((u: any) => u.email === email);
    
    if (existingUser) {
      return false; // User already exists
    }

    const newUser = {
      id: Date.now().toString(),
      email,
      password,
      name,
      createdAt: new Date().toISOString()
    };

    savedUsers.push(newUser);
    localStorage.setItem('careerpath_users', JSON.stringify(savedUsers));

    const userObj = {
      id: newUser.id,
      email: newUser.email,
      name: newUser.name,
      isGuest: false
    };
    setUser(userObj);
    localStorage.setItem('careerpath_user', JSON.stringify(userObj));
    return true;
  };

  const loginAsGuest = () => {
    const guestUser = {
      id: 'guest',
      email: 'guest@example.com',
      name: 'Guest User',
      isGuest: true
    };
    setUser(guestUser);
    localStorage.setItem('careerpath_user', JSON.stringify(guestUser));
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem('careerpath_user');
  };

  const value = {
    user,
    login,
    signup,
    loginAsGuest,
    logout,
    isAuthenticated: !!user
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
};