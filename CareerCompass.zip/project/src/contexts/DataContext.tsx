import React, { createContext, useContext, useState, useEffect } from 'react';
import { useAuth } from './AuthContext';

export interface Company {
  id: string;
  name: string;
  logo: string;
  industry: string;
  location: string;
  overview: string;
  services: string[];
  skillsRequired: string[];
  techStack: string[];
  learningResources: Array<{
    title: string;
    url: string;
    type: 'video' | 'documentation' | 'blog';
  }>;
  internshipDetails: {
    available: boolean;
    duration: string;
    requirements: string[];
  };
  jobRoles: Array<{
    title: string;
    experience: string;
    salary: string;
  }>;
  hiringStats: {
    totalHires: number;
    internshipConversions: number;
    averagePackage: string;
    hiringDepartments: Array<{
      department: string;
      openings: number;
      urgency: 'high' | 'medium' | 'low';
    }>;
  };
  companyHistory: {
    established: string;
    currentCEO: string;
    focusDepartment: string;
    fresherSupport: string[];
    keyMilestones: string[];
  };
  projectsForFreshers: {
    beginner: Array<{
      title: string;
      description: string;
      technologies: string[];
      estimatedTime: string;
    }>;
    intermediate: Array<{
      title: string;
      description: string;
      technologies: string[];
      estimatedTime: string;
    }>;
    certifications: Array<{
      title: string;
      provider: string;
      url: string;
      duration: string;
      isFree: boolean;
    }>;
  };
}

export interface RoadmapItem {
  id: string;
  title: string;
  description: string;
  type: 'technology' | 'skill';
  resources: Array<{
    title: string;
    url: string;
    type: 'video' | 'documentation' | 'blog';
  }>;
  completed: boolean;
  companyId: string;
}

export interface Notification {
  id: string;
  title: string;
  date: string;
  type: 'internship' | 'drive' | 'event';
  url: string;
  read: boolean;
}

export interface UserRequirement {
  id: string;
  type: 'role' | 'location' | 'salary' | 'experience' | 'skills' | 'industry';
  value: string;
  priority: 'high' | 'medium' | 'low';
}

export interface AutoApplication {
  id: string;
  title: string;
  company: string;
  type: 'internship' | 'workshop' | 'program';
  deadline: string;
  status: 'pending' | 'applied' | 'rejected' | 'accepted';
  matchScore: number;
  requirements: string[];
}

interface DataContextType {
  companies: Company[];
  roadmapItems: RoadmapItem[];
  notifications: Notification[];
  userRequirements: UserRequirement[];
  autoApplications: AutoApplication[];
  addCompany: (company: Omit<Company, 'id'>) => void;
  addToRoadmap: (companyId: string) => void;
  toggleRoadmapItem: (id: string) => void;
  markNotificationAsRead: (id: string) => void;
  addRequirement: (requirement: Omit<UserRequirement, 'id'>) => void;
  updateRequirement: (id: string, requirement: Partial<UserRequirement>) => void;
  deleteRequirement: (id: string) => void;
  applyToOpportunity: (id: string) => void;
}

const DataContext = createContext<DataContextType | undefined>(undefined);

export const useData = () => {
  const context = useContext(DataContext);
  if (context === undefined) {
    throw new Error('useData must be used within a DataProvider');
  }
  return context;
};

const companyData: Record<string, Partial<Company>> = {
  'Google': {
    skills: ['Problem Solving', 'System Design', 'Leadership', 'Communication', 'Data Analysis'],
    tech: ['Go', 'Python', 'Java', 'C++', 'TensorFlow', 'Kubernetes', 'BigQuery', 'Angular'],
    resources: [
      { title: 'Google AI Course', url: 'https://ai.google/education/', type: 'documentation' },
      { title: 'Go Programming', url: 'https://golang.org/doc/', type: 'documentation' },
      { title: 'TensorFlow Tutorials', url: 'https://tensorflow.org/tutorials', type: 'documentation' }
    ],
    hiringStats: {
      totalHires: 20000,
      internshipConversions: 85,
      averagePackage: '$130,000',
      hiringDepartments: [
        { department: 'Software Engineering', openings: 500, urgency: 'high' },
        { department: 'Data Science', openings: 200, urgency: 'high' },
        { department: 'Product Management', openings: 150, urgency: 'medium' },
        { department: 'UX Design', openings: 100, urgency: 'medium' },
        { department: 'Cloud Engineering', openings: 300, urgency: 'high' },
        { department: 'AI/ML Research', openings: 180, urgency: 'high' }
      ]
    },
    companyHistory: {
      established: '1998',
      currentCEO: 'Sundar Pichai',
      focusDepartment: 'AI and Machine Learning',
      fresherSupport: [
        'Comprehensive onboarding program',
        'Mentorship from senior engineers',
        'Internal learning platforms (Coursera for Business)',
        'Rotation programs across teams',
        '20% time for personal projects'
      ],
      keyMilestones: [
        '1998: Founded by Larry Page and Sergey Brin',
        '2000: Launched AdWords',
        '2004: IPO and Gmail launch',
        '2015: Alphabet restructuring',
        '2016: Sundar Pichai becomes CEO'
      ]
    },
    projectsForFreshers: {
      beginner: [
        {
          title: 'Personal Portfolio Website',
          description: 'Build a responsive portfolio using HTML, CSS, and JavaScript',
          technologies: ['HTML', 'CSS', 'JavaScript', 'Git'],
          estimatedTime: '1-2 weeks'
        },
        {
          title: 'Todo App with Local Storage',
          description: 'Create a task management app with CRUD operations',
          technologies: ['JavaScript', 'HTML', 'CSS', 'Local Storage'],
          estimatedTime: '1 week'
        }
      ],
      intermediate: [
        {
          title: 'Real-time Chat Application',
          description: 'Build a chat app using WebSockets and Node.js',
          technologies: ['Node.js', 'Socket.io', 'Express', 'MongoDB'],
          estimatedTime: '3-4 weeks'
        },
        {
          title: 'Machine Learning Image Classifier',
          description: 'Create an image classification model using TensorFlow',
          technologies: ['Python', 'TensorFlow', 'Keras', 'OpenCV'],
          estimatedTime: '4-6 weeks'
        }
      ],
      certifications: [
        {
          title: 'Google Cloud Digital Leader',
          provider: 'Google Cloud',
          url: 'https://cloud.google.com/certification/cloud-digital-leader',
          duration: '3-6 months',
          isFree: false
        },
        {
          title: 'TensorFlow Developer Certificate',
          provider: 'TensorFlow',
          url: 'https://www.tensorflow.org/certificate',
          duration: '2-4 months',
          isFree: false
        }
      ]
    }
  },
  'Microsoft': {
    skills: ['Cloud Architecture', 'DevOps', 'Project Management', 'Collaboration', 'Innovation'],
    tech: ['C#', '.NET', 'Azure', 'TypeScript', 'PowerShell', 'SQL Server', 'Power BI', 'Teams SDK'],
    resources: [
      { title: 'Azure Fundamentals', url: 'https://docs.microsoft.com/azure/', type: 'documentation' },
      { title: 'C# Programming Guide', url: 'https://docs.microsoft.com/dotnet/csharp/', type: 'documentation' },
      { title: '.NET Core Tutorial', url: 'https://dotnet.microsoft.com/learn', type: 'documentation' }
    ],
    hiringStats: {
      totalHires: 18000,
      internshipConversions: 82,
      averagePackage: '$125,000',
      hiringDepartments: [
        { department: 'Cloud Solutions', openings: 400, urgency: 'high' },
        { department: 'Software Engineering', openings: 450, urgency: 'high' },
        { department: 'DevOps Engineering', openings: 200, urgency: 'medium' },
        { department: 'Data Engineering', openings: 180, urgency: 'high' },
        { department: 'Cybersecurity', openings: 150, urgency: 'high' },
        { department: 'Product Marketing', openings: 120, urgency: 'low' }
      ]
    },
    companyHistory: {
      established: '1975',
      currentCEO: 'Satya Nadella',
      focusDepartment: 'Cloud Computing and AI',
      fresherSupport: [
        'Microsoft Learn platform access',
        'Buddy system for new hires',
        'Hackathons and innovation challenges',
        'Cross-functional project opportunities',
        'Free Azure credits for learning'
      ],
      keyMilestones: [
        '1975: Founded by Bill Gates and Paul Allen',
        '1985: Windows 1.0 released',
        '2001: Xbox launched',
        '2014: Satya Nadella becomes CEO',
        '2016: LinkedIn acquisition'
      ]
    },
    projectsForFreshers: {
      beginner: [
        {
          title: 'Azure Static Web App',
          description: 'Deploy a static website using Azure Static Web Apps',
          technologies: ['HTML', 'CSS', 'JavaScript', 'Azure'],
          estimatedTime: '1 week'
        },
        {
          title: 'C# Console Calculator',
          description: 'Build a scientific calculator using C#',
          technologies: ['C#', '.NET', 'Visual Studio'],
          estimatedTime: '1-2 weeks'
        }
      ],
      intermediate: [
        {
          title: 'ASP.NET Core Web API',
          description: 'Create a RESTful API with authentication',
          technologies: ['ASP.NET Core', 'Entity Framework', 'SQL Server'],
          estimatedTime: '3-4 weeks'
        },
        {
          title: 'Power BI Dashboard',
          description: 'Build interactive dashboards for data visualization',
          technologies: ['Power BI', 'DAX', 'Power Query'],
          estimatedTime: '2-3 weeks'
        }
      ],
      certifications: [
        {
          title: 'Azure Fundamentals (AZ-900)',
          provider: 'Microsoft',
          url: 'https://docs.microsoft.com/certifications/azure-fundamentals/',
          duration: '1-2 months',
          isFree: true
        },
        {
          title: 'Azure Developer Associate (AZ-204)',
          provider: 'Microsoft',
          url: 'https://docs.microsoft.com/certifications/azure-developer/',
          duration: '3-4 months',
          isFree: false
        }
      ]
    }
  },
  'Apple': {
    skills: ['Design Thinking', 'User Experience', 'Innovation', 'Attention to Detail', 'Quality Focus'],
    tech: ['Swift', 'Objective-C', 'iOS SDK', 'macOS', 'Xcode', 'Core Data', 'SwiftUI', 'Metal'],
    resources: [
      { title: 'Swift Programming', url: 'https://swift.org/documentation/', type: 'documentation' },
      { title: 'iOS Development', url: 'https://developer.apple.com/ios/', type: 'documentation' },
      { title: 'SwiftUI Tutorials', url: 'https://developer.apple.com/tutorials/swiftui', type: 'documentation' }
    ],
    hiringStats: {
      totalHires: 12000,
      internshipConversions: 78,
      averagePackage: '$140,000',
      hiringDepartments: [
        { department: 'iOS Development', openings: 300, urgency: 'high' },
        { department: 'Hardware Engineering', openings: 250, urgency: 'high' },
        { department: 'Design', openings: 150, urgency: 'medium' },
        { department: 'Machine Learning', openings: 200, urgency: 'high' },
        { department: 'Quality Assurance', openings: 180, urgency: 'medium' },
        { department: 'Product Management', openings: 100, urgency: 'low' }
      ]
    },
    companyHistory: {
      established: '1976',
      currentCEO: 'Tim Cook',
      focusDepartment: 'Product Design and Innovation',
      fresherSupport: [
        'Apple University internal training',
        'Design thinking workshops',
        'Cross-functional collaboration',
        'Innovation time allocation',
        'Mentorship from design leaders'
      ],
      keyMilestones: [
        '1976: Founded by Steve Jobs, Steve Wozniak, and Ronald Wayne',
        '1984: Macintosh computer launched',
        '2001: iPod released',
        '2007: iPhone revolutionizes smartphones',
        '2011: Tim Cook becomes CEO'
      ]
    },
    projectsForFreshers: {
      beginner: [
        {
          title: 'iOS Calculator App',
          description: 'Build a basic calculator app for iOS',
          technologies: ['Swift', 'UIKit', 'Xcode'],
          estimatedTime: '2 weeks'
        },
        {
          title: 'Weather App',
          description: 'Create a weather app using APIs',
          technologies: ['Swift', 'SwiftUI', 'REST APIs'],
          estimatedTime: '2-3 weeks'
        }
      ],
      intermediate: [
        {
          title: 'Social Media App',
          description: 'Build a photo-sharing app with Core Data',
          technologies: ['Swift', 'Core Data', 'CloudKit', 'SwiftUI'],
          estimatedTime: '6-8 weeks'
        },
        {
          title: 'AR Shopping App',
          description: 'Create an augmented reality shopping experience',
          technologies: ['Swift', 'ARKit', 'SceneKit', 'RealityKit'],
          estimatedTime: '8-10 weeks'
        }
      ],
      certifications: [
        {
          title: 'iOS App Development with Swift',
          provider: 'Apple',
          url: 'https://developer.apple.com/swift/',
          duration: '3-6 months',
          isFree: true
        },
        {
          title: 'App Development with Swift Certification',
          provider: 'Apple',
          url: 'https://www.apple.com/education/k12/teaching-code/',
          duration: '6-12 months',
          isFree: true
        }
      ]
    }
  },
  'Amazon': {
    skills: ['Customer Obsession', 'Ownership', 'Invent and Simplify', 'Scale Thinking', 'Bias for Action'],
    tech: ['Java', 'Python', 'AWS', 'DynamoDB', 'Lambda', 'EC2', 'S3', 'Elasticsearch'],
    resources: [
      { title: 'AWS Training', url: 'https://aws.amazon.com/training/', type: 'documentation' },
      { title: 'Java Development', url: 'https://docs.oracle.com/javase/', type: 'documentation' },
      { title: 'DynamoDB Guide', url: 'https://docs.aws.amazon.com/dynamodb/', type: 'documentation' }
    ],
    hiringStats: {
      totalHires: 25000,
      internshipConversions: 80,
      averagePackage: '$120,000',
      hiringDepartments: [
        { department: 'Software Development', openings: 600, urgency: 'high' },
        { department: 'Cloud Engineering', openings: 400, urgency: 'high' },
        { department: 'Data Science', openings: 300, urgency: 'high' },
        { department: 'DevOps', openings: 250, urgency: 'medium' },
        { department: 'Logistics Engineering', openings: 200, urgency: 'medium' },
        { department: 'Alexa Development', openings: 180, urgency: 'high' }
      ]
    },
    companyHistory: {
      established: '1994',
      currentCEO: 'Andy Jassy',
      focusDepartment: 'Cloud Computing and E-commerce',
      fresherSupport: [
        'Amazon Technical Apprenticeship',
        'Career Choice program',
        'Internal mobility opportunities',
        'AWS training and certification',
        'Leadership development programs'
      ],
      keyMilestones: [
        '1994: Founded by Jeff Bezos as online bookstore',
        '2002: AWS web services launched',
        '2007: Kindle e-reader released',
        '2014: Alexa and Echo introduced',
        '2021: Andy Jassy becomes CEO'
      ]
    },
    projectsForFreshers: {
      beginner: [
        {
          title: 'AWS S3 File Uploader',
          description: 'Build a file upload service using AWS S3',
          technologies: ['JavaScript', 'AWS S3', 'Node.js'],
          estimatedTime: '1-2 weeks'
        },
        {
          title: 'Serverless API',
          description: 'Create a REST API using AWS Lambda',
          technologies: ['Python', 'AWS Lambda', 'API Gateway'],
          estimatedTime: '2 weeks'
        }
      ],
      intermediate: [
        {
          title: 'E-commerce Microservice',
          description: 'Build a scalable e-commerce backend',
          technologies: ['Java', 'Spring Boot', 'DynamoDB', 'Docker'],
          estimatedTime: '6-8 weeks'
        },
        {
          title: 'Real-time Analytics Dashboard',
          description: 'Create a dashboard using AWS services',
          technologies: ['Python', 'AWS Kinesis', 'ElasticSearch', 'Kibana'],
          estimatedTime: '8-10 weeks'
        }
      ],
      certifications: [
        {
          title: 'AWS Cloud Practitioner',
          provider: 'Amazon Web Services',
          url: 'https://aws.amazon.com/certification/certified-cloud-practitioner/',
          duration: '1-2 months',
          isFree: false
        },
        {
          title: 'AWS Solutions Architect Associate',
          provider: 'Amazon Web Services',
          url: 'https://aws.amazon.com/certification/certified-solutions-architect-associate/',
          duration: '3-6 months',
          isFree: false
        }
      ]
    }
  },
  'Meta': {
    skills: ['Social Impact', 'Move Fast', 'Be Bold', 'Focus on Impact', 'Be Open'],
    tech: ['React', 'React Native', 'GraphQL', 'PHP', 'Hack', 'PyTorch', 'Relay', 'Flow'],
    resources: [
      { title: 'React Documentation', url: 'https://react.dev/', type: 'documentation' },
      { title: 'GraphQL Tutorial', url: 'https://graphql.org/learn/', type: 'documentation' },
      { title: 'PyTorch Tutorials', url: 'https://pytorch.org/tutorials/', type: 'documentation' }
    ],
    hiringStats: {
      totalHires: 15000,
      internshipConversions: 75,
      averagePackage: '$135,000',
      hiringDepartments: [
        { department: 'Frontend Engineering', openings: 350, urgency: 'high' },
        { department: 'Backend Engineering', openings: 300, urgency: 'high' },
        { department: 'Mobile Development', openings: 250, urgency: 'high' },
        { department: 'AI Research', openings: 200, urgency: 'high' },
        { department: 'VR/AR Development', openings: 180, urgency: 'medium' },
        { department: 'Data Engineering', openings: 150, urgency: 'medium' }
      ]
    },
    companyHistory: {
      established: '2004',
      currentCEO: 'Mark Zuckerberg',
      focusDepartment: 'Metaverse and Social Technology',
      fresherSupport: [
        'Bootcamp rotation program',
        'Peer mentorship networks',
        'Hackathons and innovation weeks',
        'Open source contribution opportunities',
        'Cross-team collaboration projects'
      ],
      keyMilestones: [
        '2004: Founded as Facebook by Mark Zuckerberg',
        '2012: Instagram acquisition',
        '2014: WhatsApp acquisition',
        '2021: Rebranded to Meta',
        '2021: Focus shift to Metaverse'
      ]
    },
    projectsForFreshers: {
      beginner: [
        {
          title: 'React Social Feed',
          description: 'Build a social media feed using React',
          technologies: ['React', 'JavaScript', 'CSS', 'REST APIs'],
          estimatedTime: '2-3 weeks'
        },
        {
          title: 'GraphQL Blog API',
          description: 'Create a blog API using GraphQL',
          technologies: ['GraphQL', 'Node.js', 'Apollo Server'],
          estimatedTime: '2 weeks'
        }
      ],
      intermediate: [
        {
          title: 'React Native Chat App',
          description: 'Build a cross-platform messaging app',
          technologies: ['React Native', 'Firebase', 'Redux'],
          estimatedTime: '6-8 weeks'
        },
        {
          title: 'VR Social Experience',
          description: 'Create a VR social interaction platform',
          technologies: ['React VR', 'WebXR', 'Three.js'],
          estimatedTime: '10-12 weeks'
        }
      ],
      certifications: [
        {
          title: 'React Developer Certification',
          provider: 'Meta',
          url: 'https://www.coursera.org/professional-certificates/meta-react-native',
          duration: '3-6 months',
          isFree: false
        },
        {
          title: 'Meta Front-End Developer',
          provider: 'Meta',
          url: 'https://www.coursera.org/professional-certificates/meta-front-end-developer',
          duration: '6-8 months',
          isFree: false
        }
      ]
    }
  }
};

// Helper function to ensure company data has all required properties with defaults
const hydrateCompany = (partialCompany: Partial<Company>): Company => {
  const companyInfo = companyData[partialCompany.name || ''] || {};
  
  return {
    id: partialCompany.id || Date.now().toString(),
    name: partialCompany.name || 'Unknown Company',
    logo: partialCompany.logo || '',
    industry: partialCompany.industry || 'Technology',
    location: partialCompany.location || 'Unknown',
    overview: partialCompany.overview || 'No overview available',
    services: partialCompany.services || ['Software Development', 'Technology Solutions'],
    skillsRequired: partialCompany.skillsRequired || companyInfo.skills || ['Problem Solving', 'Communication', 'Teamwork', 'Leadership', 'Time Management'],
    techStack: partialCompany.techStack || companyInfo.tech || ['JavaScript', 'Python', 'React', 'Node.js', 'AWS', 'Docker', 'Git'],
    learningResources: partialCompany.learningResources || companyInfo.resources || [
      { title: 'JavaScript Fundamentals', url: 'https://javascript.info/', type: 'documentation' },
      { title: 'Python Tutorial', url: 'https://python.org/doc/', type: 'documentation' }
    ],
    internshipDetails: partialCompany.internshipDetails || {
      available: true,
      duration: '3-6 months',
      requirements: ['Academic excellence', 'Programming skills', 'Problem-solving ability']
    },
    jobRoles: partialCompany.jobRoles || [
      {
        title: 'Software Engineer Intern',
        experience: 'Fresher',
        salary: '$60,000 - $80,000'
      },
      {
        title: 'Junior Developer',
        experience: 'Fresher',
        salary: '$70,000 - $90,000'
      },
      {
        title: 'Graduate Trainee',
        experience: 'Fresher',
        salary: '$65,000 - $85,000'
      }
    ],
    hiringStats: partialCompany.hiringStats || companyInfo.hiringStats || {
      totalHires: 1000,
      internshipConversions: 75,
      averagePackage: '$100,000',
      hiringDepartments: [
        { department: 'Software Engineering', openings: 100, urgency: 'medium' },
        { department: 'Product Management', openings: 50, urgency: 'low' }
      ]
    },
    companyHistory: partialCompany.companyHistory || companyInfo.companyHistory || {
      established: '2000',
      currentCEO: 'CEO Name',
      focusDepartment: 'Technology',
      fresherSupport: ['Mentorship program', 'Training sessions'],
      keyMilestones: ['Founded', 'First product launch']
    },
    projectsForFreshers: partialCompany.projectsForFreshers || companyInfo.projectsForFreshers || {
      beginner: [
        {
          title: 'Basic Web App',
          description: 'Build a simple web application',
          technologies: ['HTML', 'CSS', 'JavaScript'],
          estimatedTime: '2 weeks'
        }
      ],
      intermediate: [
        {
          title: 'Full Stack App',
          description: 'Build a complete web application',
          technologies: ['React', 'Node.js', 'MongoDB'],
          estimatedTime: '4-6 weeks'
        }
      ],
      certifications: [
        {
          title: 'Web Development Basics',
          provider: 'FreeCodeCamp',
          url: 'https://freecodecamp.org',
          duration: '3 months',
          isFree: true
        }
      ]
    }
  };
};

export const DataProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const { user } = useAuth();
  const [companies, setCompanies] = useState<Company[]>([]);
  const [roadmapItems, setRoadmapItems] = useState<RoadmapItem[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [userRequirements, setUserRequirements] = useState<UserRequirement[]>([]);
  const [autoApplications, setAutoApplications] = useState<AutoApplication[]>([]);

  useEffect(() => {
    if (user) {
      loadUserData();
    }
  }, [user]);

  const loadUserData = () => {
    const savedCompanies = localStorage.getItem(`career_compass_companies_${user?.id}`);
    const savedRoadmap = localStorage.getItem(`career_compass_roadmap_${user?.id}`);
    const savedNotifications = localStorage.getItem(`career_compass_notifications_${user?.id}`);
    const savedRequirements = localStorage.getItem(`career_compass_requirements_${user?.id}`);
    const savedApplications = localStorage.getItem(`career_compass_applications_${user?.id}`);

    if (savedCompanies) {
      const parsedCompanies = JSON.parse(savedCompanies);
      // Hydrate each company to ensure all properties exist
      const hydratedCompanies = parsedCompanies.map((company: Partial<Company>) => hydrateCompany(company));
      setCompanies(hydratedCompanies);
    }
    if (savedRoadmap) {
      setRoadmapItems(JSON.parse(savedRoadmap));
    }
    if (savedRequirements) {
      setUserRequirements(JSON.parse(savedRequirements));
    }
    if (savedApplications) {
      setAutoApplications(JSON.parse(savedApplications));
    } else {
      // Initialize with sample applications
      const sampleApplications: AutoApplication[] = [
        {
          id: '1',
          title: 'Google Summer of Code 2024',
          company: 'Google',
          type: 'program',
          deadline: '2024-04-02',
          status: 'pending',
          matchScore: 92,
          requirements: ['Open Source Contribution', 'Programming Skills', 'University Student']
        },
        {
          id: '2',
          title: 'Microsoft Learn Student Ambassador',
          company: 'Microsoft',
          type: 'program',
          deadline: '2024-03-15',
          status: 'pending',
          matchScore: 88,
          requirements: ['Leadership Skills', 'Community Building', 'Technical Knowledge']
        },
        {
          id: '3',
          title: 'Meta Frontend Workshop',
          company: 'Meta',
          type: 'workshop',
          deadline: '2024-02-28',
          status: 'pending',
          matchScore: 85,
          requirements: ['React Knowledge', 'JavaScript Proficiency', 'Portfolio']
        }
      ];
      setAutoApplications(sampleApplications);
      localStorage.setItem(`career_compass_applications_${user?.id}`, JSON.stringify(sampleApplications));
    }
    
    if (savedNotifications) {
      setNotifications(JSON.parse(savedNotifications));
    } else {
      // Initialize with sample notifications
      const sampleNotifications: Notification[] = [
        {
          id: '1',
          title: 'Google Summer Internship Applications Open',
          date: '2024-01-15',
          type: 'internship',
          url: 'https://careers.google.com',
          read: false
        },
        {
          id: '2',
          title: 'Microsoft Campus Drive at IIT Delhi',
          date: '2024-01-10',
          type: 'drive',
          url: 'https://careers.microsoft.com',
          read: false
        },
        {
          id: '3',
          title: 'React Conference 2024 - Free Registration',
          date: '2024-01-08',
          type: 'event',
          url: 'https://reactconf.com',
          read: false
        }
      ];
      setNotifications(sampleNotifications);
      localStorage.setItem(`career_compass_notifications_${user?.id}`, JSON.stringify(sampleNotifications));
    }
  };

  const addCompany = (companyInput: Omit<Company, 'id'>) => {
    // Use hydrateCompany to ensure the new company has all required properties
    const newCompany = hydrateCompany(companyInput);
    
    const updatedCompanies = [...companies, newCompany];
    setCompanies(updatedCompanies);
    localStorage.setItem(`career_compass_companies_${user?.id}`, JSON.stringify(updatedCompanies));
  };

  const addToRoadmap = (companyId: string) => {
    const company = companies.find(c => c.id === companyId);
    if (!company) return;

    const newRoadmapItems: RoadmapItem[] = [
      ...company.techStack.map(tech => ({
        id: `${companyId}-${tech}-${Date.now()}`,
        title: tech,
        description: `Master ${tech} technology for ${company.name}`,
        type: 'technology' as const,
        resources: company.learningResources.filter(r => r.title.toLowerCase().includes(tech.toLowerCase())),
        completed: false,
        companyId
      })),
      ...company.skillsRequired.map(skill => ({
        id: `${companyId}-${skill}-${Date.now()}`,
        title: skill,
        description: `Develop ${skill} expertise for ${company.name}`,
        type: 'skill' as const,
        resources: company.learningResources.filter(r => r.title.toLowerCase().includes(skill.toLowerCase())),
        completed: false,
        companyId
      }))
    ];

    const updatedRoadmap = [...roadmapItems, ...newRoadmapItems];
    setRoadmapItems(updatedRoadmap);
    localStorage.setItem(`career_compass_roadmap_${user?.id}`, JSON.stringify(updatedRoadmap));
  };

  const toggleRoadmapItem = (id: string) => {
    const updatedRoadmap = roadmapItems.map(item =>
      item.id === id ? { ...item, completed: !item.completed } : item
    );
    setRoadmapItems(updatedRoadmap);
    localStorage.setItem(`career_compass_roadmap_${user?.id}`, JSON.stringify(updatedRoadmap));
  };

  const markNotificationAsRead = (id: string) => {
    const updatedNotifications = notifications.map(notif =>
      notif.id === id ? { ...notif, read: true } : notif
    );
    setNotifications(updatedNotifications);
    localStorage.setItem(`career_compass_notifications_${user?.id}`, JSON.stringify(updatedNotifications));
  };

  const addRequirement = (requirement: Omit<UserRequirement, 'id'>) => {
    const newRequirement: UserRequirement = {
      ...requirement,
      id: Date.now().toString()
    };
    const updatedRequirements = [...userRequirements, newRequirement];
    setUserRequirements(updatedRequirements);
    localStorage.setItem(`career_compass_requirements_${user?.id}`, JSON.stringify(updatedRequirements));
  };

  const updateRequirement = (id: string, requirement: Partial<UserRequirement>) => {
    const updatedRequirements = userRequirements.map(req =>
      req.id === id ? { ...req, ...requirement } : req
    );
    setUserRequirements(updatedRequirements);
    localStorage.setItem(`career_compass_requirements_${user?.id}`, JSON.stringify(updatedRequirements));
  };

  const deleteRequirement = (id: string) => {
    const updatedRequirements = userRequirements.filter(req => req.id !== id);
    setUserRequirements(updatedRequirements);
    localStorage.setItem(`career_compass_requirements_${user?.id}`, JSON.stringify(updatedRequirements));
  };

  const applyToOpportunity = (id: string) => {
    const updatedApplications = autoApplications.map(app =>
      app.id === id ? { ...app, status: 'applied' as const } : app
    );
    setAutoApplications(updatedApplications);
    localStorage.setItem(`career_compass_applications_${user?.id}`, JSON.stringify(updatedApplications));
  };

  const value = {
    companies,
    roadmapItems,
    notifications,
    userRequirements,
    autoApplications,
    addCompany,
    addToRoadmap,
    toggleRoadmapItem,
    markNotificationAsRead,
    addRequirement,
    updateRequirement,
    deleteRequirement,
    applyToOpportunity
  };

  return <DataContext.Provider value={value}>{children}</DataContext.Provider>;
};