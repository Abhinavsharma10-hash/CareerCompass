import React, { createContext, useContext, useState } from 'react';

export interface ChatMessage {
  id: string;
  text: string;
  isBot: boolean;
  timestamp: Date;
}

interface ChatContextType {
  messages: ChatMessage[];
  isOpen: boolean;
  toggleChat: () => void;
  sendMessage: (text: string) => void;
}

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export const useChat = () => {
  const context = useContext(ChatContext);
  if (context === undefined) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
};

export const ChatProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [messages, setMessages] = useState<ChatMessage[]>([
    {
      id: '1',
      text: 'Hello! I\'m your Career Compass AI assistant. I can help you with career guidance, company research, skill development, and application strategies. How can I assist you today?',
      isBot: true,
      timestamp: new Date()
    }
  ]);
  const [isOpen, setIsOpen] = useState(false);

  const toggleChat = () => setIsOpen(!isOpen);

  const getBotResponse = (userMessage: string): string => {
    const message = userMessage.toLowerCase();
    
    if (message.includes('company') || message.includes('research')) {
      return 'I can help you research companies! Try adding companies to your list and I\'ll provide insights about their tech stack, culture, and hiring process. What specific company are you interested in?';
    }
    
    if (message.includes('skill') || message.includes('learn')) {
      return 'Great question about skills! Based on your target companies, I recommend focusing on: React, Node.js, Python, and cloud technologies. Check your Learning Roadmap for personalized recommendations!';
    }
    
    if (message.includes('resume') || message.includes('cv')) {
      return 'For resume tips, visit the Resume Tips section! Key points: quantify achievements, tailor for each role, keep it concise, and highlight relevant tech skills. Would you like specific advice for any company?';
    }
    
    if (message.includes('interview') || message.includes('preparation')) {
      return 'Interview prep is crucial! Focus on: technical coding problems, system design (for senior roles), behavioral questions using STAR method, and company-specific research. Practice on platforms like LeetCode and HackerRank.';
    }
    
    if (message.includes('internship') || message.includes('application')) {
      return 'For internships and applications, check the Auto Applications section! I can help you find relevant opportunities and even automate applications based on your requirements. What type of role are you targeting?';
    }
    
    if (message.includes('salary') || message.includes('compensation')) {
      return 'Salary ranges vary by location and experience. For entry-level: $60-90k, mid-level: $90-140k, senior: $140k+. Check company profiles for specific data. Don\'t forget to negotiate based on your skills!';
    }
    
    if (message.includes('hello') || message.includes('hi') || message.includes('hey')) {
      return 'Hello! I\'m here to help with your career journey. You can ask me about companies, skills, interviews, resumes, or anything career-related. What would you like to know?';
    }
    
    if (message.includes('thank')) {
      return 'You\'re welcome! I\'m always here to help with your career questions. Feel free to ask anything else!';
    }
    
    return 'That\'s an interesting question! I can help you with career guidance, company research, skill development, resume tips, interview preparation, and job applications. Could you be more specific about what you\'d like to know?';
  };

  const sendMessage = (text: string) => {
    const userMessage: ChatMessage = {
      id: Date.now().toString(),
      text,
      isBot: false,
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);

    // Simulate bot response delay
    setTimeout(() => {
      const botResponse: ChatMessage = {
        id: (Date.now() + 1).toString(),
        text: getBotResponse(text),
        isBot: true,
        timestamp: new Date()
      };
      setMessages(prev => [...prev, botResponse]);
    }, 1000);
  };

  const value = {
    messages,
    isOpen,
    toggleChat,
    sendMessage
  };

  return <ChatContext.Provider value={value}>{children}</ChatContext.Provider>;
};