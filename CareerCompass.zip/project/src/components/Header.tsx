import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { useData } from '../contexts/DataContext';
import { Bell, MessageCircle } from 'lucide-react';
import { useChat } from '../contexts/ChatContext';

const Header: React.FC = () => {
  const { user } = useAuth();
  const { notifications } = useData();
  const { toggleChat } = useChat();
  
  const unreadCount = notifications.filter(n => !n.read).length;

  return (
    <header className="bg-white shadow-sm border-b border-gray-200 px-6 py-4">
      <div className="flex items-center justify-between">
        <div>
          <h2 className="text-2xl font-bold text-gray-900">
            Welcome back, {user?.name?.split(' ')[0] || 'User'}!
          </h2>
          <p className="text-gray-600">
            {user?.isGuest 
              ? 'You\'re browsing as a guest. Sign up for full AI-powered features!' 
              : 'Let\'s navigate your career journey with AI guidance.'}
          </p>
        </div>
        
        <div className="flex items-center space-x-4">
          <button
            onClick={toggleChat}
            className="relative p-2 text-gray-600 hover:text-blue-600 transition-colors duration-200"
          >
            <MessageCircle className="h-6 w-6" />
          </button>
          
          <div className="relative">
            <Bell className="h-6 w-6 text-gray-600" />
            {unreadCount > 0 && (
              <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full h-5 w-5 flex items-center justify-center">
                {unreadCount}
              </span>
            )}
          </div>
        </div>
      </div>
    </header>
  );
};

export default Header;